
import React, { useState, useEffect } from 'react';
import { NoteItem, FactCheckHistoryItem } from '../types';

const ArchiveView: React.FC = () => {
  const [archivedNotes, setArchivedNotes] = useState<NoteItem[]>([]);
  const [archivedFacts, setArchivedFacts] = useState<FactCheckHistoryItem[]>([]);

  useEffect(() => {
    const allNotes = JSON.parse(localStorage.getItem('study_notes') || '[]');
    const allFacts = JSON.parse(localStorage.getItem('fact_history') || '[]');
    setArchivedNotes(allNotes.filter((n: NoteItem) => n.isArchived));
    setArchivedFacts(allFacts.filter((f: FactCheckHistoryItem) => f.isArchived));
  }, []);

  const unarchiveNote = (id: string) => {
    const allNotes = JSON.parse(localStorage.getItem('study_notes') || '[]');
    const updated = allNotes.map((n: NoteItem) => n.id === id ? { ...n, isArchived: false } : n);
    localStorage.setItem('study_notes', JSON.stringify(updated));
    setArchivedNotes(updated.filter((n: NoteItem) => n.isArchived));
  };

  return (
    <div className="p-4 lg:p-8 h-full max-w-5xl mx-auto space-y-8 animate-in fade-in duration-500">
      <header>
        <h2 className="text-3xl font-bold text-slate-800 dark:text-slate-100">Archive</h2>
        <p className="text-sm text-slate-500 dark:text-slate-400">Items you've stashed away for safe keeping.</p>
      </header>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        <section className="space-y-4">
          <h3 className="text-lg font-bold">Archived Notes</h3>
          {archivedNotes.length === 0 ? <p className="text-sm text-slate-400 italic">Nothing archived.</p> :
            archivedNotes.map(note => (
              <div key={note.id} className="glass p-5 rounded-2xl border border-dashed border-slate-300 dark:border-slate-700 opacity-80">
                <div className="flex justify-between items-start mb-2">
                  <h4 className="font-bold text-slate-800 dark:text-slate-100">{note.title}</h4>
                  <button onClick={() => unarchiveNote(note.id)} className="text-[10px] font-bold text-indigo-500 hover:underline">Unarchive</button>
                </div>
                <p className="text-xs text-slate-500 line-clamp-2">{note.content}</p>
              </div>
            ))
          }
        </section>

        <section className="space-y-4 opacity-50 cursor-not-allowed">
           <h3 className="text-lg font-bold">Archived Media</h3>
           <div className="border-2 border-dashed border-slate-200 dark:border-slate-800 rounded-3xl h-40 flex items-center justify-center">
              <span className="text-xs font-bold text-slate-400 uppercase tracking-widest">Storage Empty</span>
           </div>
        </section>
      </div>
    </div>
  );
};

export default ArchiveView;
