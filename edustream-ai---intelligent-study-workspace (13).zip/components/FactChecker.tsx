import React, { useState, useEffect, useRef } from 'react';
import { factCheckStatement } from '../services/geminiService';
import { Language, FactCheckHistoryItem } from '../types';

interface CheckResult { score: number; verdict: string; explanation: string; statement: string; }

const FactChecker: React.FC = () => {
  const [statement, setStatement] = useState('');
  const [isChecking, setIsChecking] = useState(false);
  const [result, setResult] = useState<CheckResult | null>(null);
  const [language, setLanguage] = useState<Language>('english');
  const [isListening, setIsListening] = useState(false);
  const lastCheckedStatement = useRef<string | null>(null);

  const handleCheck = async () => {
    const query = statement;
    if (!query.trim()) return;
    setIsChecking(true); lastCheckedStatement.current = query;
    try {
      const data = await factCheckStatement(query, language);
      const newResult = { ...data, statement: query };
      setResult(newResult);
      setStatement('');
    } catch (e) { console.error(e); } finally { setIsChecking(false); }
  };

  const startVoice = () => {
    const sr = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (!sr) return;
    const rec = new sr(); rec.lang = language === 'urdu' ? 'ur-PK' : 'en-US';
    rec.onstart = () => setIsListening(true); rec.onend = () => setIsListening(false);
    rec.onresult = (e: any) => setStatement(e.results[0][0].transcript); rec.start();
  };

  const getScoreColor = (s: number) => s > 80 ? '#10b981' : s > 50 ? '#f59e0b' : '#ef4444';
  
  const getReliabilityLevel = (s: number) => {
    if (s > 80) return "High Reliability";
    if (s > 40) return "Medium Reliability";
    return "Low Reliability";
  };

  return (
    <div className="p-8 lg:p-12 h-full max-w-6xl mx-auto space-y-12 animate-in fade-in duration-700">
      <header className="flex flex-col md:flex-row md:items-center justify-between gap-6">
        <div>
          <h2 className="text-3xl font-black text-slate-800 dark:text-white">Truth Verifier</h2>
          <p className="text-sm text-slate-400 font-bold uppercase tracking-widest mt-1">AI-Powered Evidence Analysis</p>
        </div>
        <div className="flex bg-slate-100 dark:bg-slate-900 p-1 rounded-2xl shadow-inner border border-slate-200 dark:border-slate-800 self-start">
          {(['english', 'urdu', 'roman-english'] as Language[]).map(l => (
            <button key={l} onClick={() => setLanguage(l)} className={`px-4 py-2 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all ${language === l ? 'bg-purple-600 text-white shadow-lg' : 'text-slate-500 hover:text-purple-600'}`}>
              {l.replace('-english', '')}
            </button>
          ))}
        </div>
      </header>

      <div className="grid grid-cols-1 xl:grid-cols-5 gap-12">
        <div className="xl:col-span-3 space-y-10">
          <div className="glass-card rounded-[2.5rem] p-8 space-y-6">
            <h3 className="text-lg font-bold text-slate-800 dark:text-white">Enter Statement or Claim</h3>
            <div className="relative">
              <textarea
                className="w-full h-44 bg-slate-50 dark:bg-slate-950 border-2 border-transparent focus:border-purple-500 rounded-[2rem] p-8 text-sm font-medium outline-none transition-all dark:text-white resize-none"
                placeholder="Type or use mic to verify a claim..."
                value={statement}
                onChange={e => setStatement(e.target.value)}
              />
              <button onClick={startVoice} className={`absolute bottom-6 right-6 p-3 rounded-full shadow-lg transition-all ${isListening ? 'bg-red-500 text-white animate-pulse' : 'bg-white dark:bg-slate-800 text-slate-400'}`}>
                <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M19 11a7 7 0 01-7 7m0 0a7 7 0 01-7-7m7 7v4m0 0H8m4 0h4m-4-8a3 3 0 01-3-3V5a3 3 0 116 0v6a3 3 0 01-3 3z" /></svg>
              </button>
            </div>
            <button onClick={() => handleCheck()} disabled={isChecking || !statement.trim()} className="w-full bg-purple-600 hover:bg-purple-700 text-white py-5 rounded-[1.5rem] font-black text-sm uppercase tracking-widest shadow-2xl shadow-purple-600/30 transition-all active:scale-95 disabled:opacity-50">
              {isChecking ? <div className="w-6 h-6 border-3 border-white border-t-transparent rounded-full animate-spin mx-auto"></div> : 'Analyze Reality'}
            </button>
          </div>

          {result && (
            <div className="glass-card rounded-[2.5rem] p-12 space-y-12 animate-in zoom-in-95 duration-500">
              <div className="flex flex-col md:flex-row items-center gap-12">
                <div className="relative w-56 h-56 shrink-0 flex items-center justify-center">
                  <svg viewBox="0 0 100 100" className="w-full h-full transform -rotate-90">
                    <circle cx="50" cy="50" r="44" strokeWidth="10" stroke="currentColor" fill="transparent" className="text-slate-100 dark:text-slate-800" />
                    <circle cx="50" cy="50" r="44" strokeWidth="10" stroke={getScoreColor(result.score)} fill="transparent" strokeDasharray="276.46" strokeDashoffset={276.46 - (276.46 * result.score) / 100} strokeLinecap="round" className="transition-all duration-1000" />
                  </svg>
                  <div className="absolute inset-0 flex flex-col items-center justify-center">
                    <span className="text-5xl font-black text-slate-800 dark:text-white">{result.score}%</span>
                    <span className="text-[10px] font-black text-slate-400 uppercase tracking-[0.3em] mt-2">Accuracy</span>
                  </div>
                </div>
                <div className="flex-1 space-y-6 text-center md:text-left">
                  <span className="px-6 py-2 rounded-full text-xs font-black uppercase tracking-widest text-white shadow-xl" style={{ backgroundColor: getScoreColor(result.score) }}>{result.verdict}</span>
                  <h4 className={`text-2xl font-extrabold text-slate-800 dark:text-white italic ${language === 'urdu' ? 'urdu-text' : ''}`}>"{result.statement}"</h4>
                  <p className={`text-base text-slate-500 dark:text-slate-400 font-medium leading-relaxed ${language === 'urdu' ? 'urdu-text' : ''}`}>{result.explanation}</p>
                </div>
              </div>

              <div className="space-y-4">
                 <div className="flex justify-between items-end px-2">
                    <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Truth Spectrum</span>
                    <div className="text-right">
                       <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest block mb-0.5">Confidence Level</span>
                       <span className="text-sm font-black text-slate-800 dark:text-white">{getReliabilityLevel(result.score)}</span>
                    </div>
                 </div>
                 <div className="relative h-6 w-full bg-slate-100 dark:bg-slate-900 rounded-full p-1 overflow-visible">
                    <div className="h-full rounded-full transition-all duration-1000 truth-linear-gradient" style={{ width: `${result.score}%` }}></div>
                    {/* Visual Marker Line */}
                    <div 
                      className="absolute top-0 h-8 w-0.5 bg-slate-400 dark:bg-white transition-all duration-1000 shadow-sm" 
                      style={{ left: `calc(${result.score}% - 1px)`, marginTop: '-4px' }}
                    ></div>
                 </div>
                 <div className="flex justify-between text-[10px] font-black text-slate-400 px-2">
                    <span>FALSE</span>
                    <span>LIKELY</span>
                    <span>TRUTH</span>
                 </div>
              </div>
            </div>
          )}
        </div>

        <div className="xl:col-span-2 space-y-8">
           <div className="glass-card rounded-[2.5rem] p-8">
              <h3 className="text-xs font-black text-slate-400 uppercase tracking-[0.2em] mb-8">Verification Engine</h3>
              <div className="space-y-8">
                 {[
                   { t: 'Multi-Lingual', d: 'Advanced Urdu, Roman Urdu & English NLP.', i: 'M3 5h12M9 3v2m1.048 9.5A18.022 18.022 0 016.412 9m6.088 9h7M11 21l5-10 5 10M12.751 5C11.783 10.77 8.07 15.61 3 18.129' },
                   { t: 'Dual Analysis', d: 'Score calculated via cross-referencing.', i: 'M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2' },
                 ].map((item, idx) => (
                   <div key={idx} className="flex space-x-5">
                      <div className="w-12 h-12 rounded-2xl bg-purple-50 dark:bg-slate-900 text-purple-600 flex items-center justify-center shrink-0">
                         <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d={item.i} /></svg>
                      </div>
                      <div><p className="font-bold text-slate-800 dark:text-white text-sm">{item.t}</p><p className="text-xs text-slate-500 font-medium leading-relaxed">{item.d}</p></div>
                   </div>
                 ))}
              </div>
           </div>
        </div>
      </div>
    </div>
  );
};

export default FactChecker;