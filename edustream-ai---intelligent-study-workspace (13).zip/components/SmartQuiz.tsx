
import React, { useState } from 'react';
import { generateQuiz } from '../services/geminiService';

interface Question {
  question: string;
  options: string[];
  correctAnswer: number;
  explanation: string;
}

const SmartQuiz: React.FC = () => {
  const [inputContent, setInputContent] = useState('');
  const [mode, setMode] = useState<'notes' | 'topic'>('topic');
  const [isGenerating, setIsGenerating] = useState(false);
  const [questions, setQuestions] = useState<Question[]>([]);
  const [currentIdx, setCurrentIdx] = useState(0);
  const [score, setScore] = useState(0);
  const [quizState, setQuizState] = useState<'input' | 'playing' | 'result'>('input');
  const [feedback, setFeedback] = useState<number | null>(null);

  const handleStart = async () => {
    if (!inputContent.trim()) return;
    setIsGenerating(true);
    try {
      const qs = await generateQuiz(inputContent, mode);
      if (qs && qs.length > 0) {
        setQuestions(qs);
        setQuizState('playing');
        setCurrentIdx(0);
        setScore(0);
      } else {
        alert("AI could not generate questions for this input. Try something else!");
      }
    } catch (e) {
      alert("Failed to generate quiz. Check your connection or API key.");
    } finally {
      setIsGenerating(false);
    }
  };

  const handleSelect = (idx: number) => {
    if (feedback !== null) return;
    setFeedback(idx);
    if (idx === questions[currentIdx].correctAnswer) setScore(s => s + 1);
    
    setTimeout(() => {
      setFeedback(null);
      if (currentIdx < questions.length - 1) {
        setCurrentIdx(currentIdx + 1);
      } else {
        setQuizState('result');
      }
    }, 2500);
  };

  return (
    <div className="p-8 lg:p-12 max-w-4xl mx-auto space-y-12 h-full flex flex-col items-center animate-in fade-in duration-700">
      {quizState === 'input' && (
        <div className="w-full max-w-2xl space-y-8 text-center">
          <div className="space-y-2">
            <h2 className="text-4xl font-black text-slate-800 tracking-tighter">AI Smart Quiz</h2>
            <p className="text-slate-400 font-bold uppercase tracking-widest text-xs">Instantly test your knowledge</p>
          </div>
          
          <div className="flex bg-white dark:bg-slate-900 p-1 rounded-2xl border border-brand-200 shadow-sm w-fit mx-auto">
             <button onClick={() => setMode('topic')} className={`px-6 py-2 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all ${mode === 'topic' ? 'bg-brand-600 text-white shadow-lg' : 'text-slate-400 hover:text-brand-500'}`}>By Topic Name</button>
             <button onClick={() => setMode('notes')} className={`px-6 py-2 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all ${mode === 'notes' ? 'bg-brand-600 text-white shadow-lg' : 'text-slate-400 hover:text-brand-500'}`}>By Pasted Notes</button>
          </div>

          <div className="glass-card p-8 rounded-[3rem] border-brand-200 shadow-xl space-y-6">
            {mode === 'topic' ? (
              <div className="space-y-4">
                <p className="text-sm text-slate-500 font-medium">Enter a subject like "Computer Networking", "World War II", or "Islamic History"</p>
                <input 
                  type="text"
                  className="w-full bg-slate-50 dark:bg-slate-900 border-2 border-transparent focus:border-brand-500 rounded-2xl p-6 text-center font-bold outline-none transition-all dark:text-white text-xl shadow-inner"
                  placeholder="Subject Name..."
                  value={inputContent}
                  onChange={(e) => setInputContent(e.target.value)}
                />
              </div>
            ) : (
              <div className="space-y-4">
                <p className="text-sm text-slate-500 font-medium">Paste your detailed notes below for AI to analyze</p>
                <textarea 
                  className="w-full h-64 bg-slate-50 dark:bg-slate-900 border-2 border-transparent focus:border-brand-500 rounded-[2rem] p-8 text-sm outline-none transition-all dark:text-white resize-none shadow-inner"
                  placeholder="Paste study material here..."
                  value={inputContent}
                  onChange={(e) => setInputContent(e.target.value)}
                />
              </div>
            )}
            <button 
              onClick={handleStart} 
              disabled={isGenerating || !inputContent} 
              className="w-full bg-brand-600 hover:bg-brand-700 text-white py-5 rounded-[1.5rem] font-black uppercase text-xs tracking-widest shadow-2xl shadow-brand-200 transition-all active:scale-95 disabled:opacity-50"
            >
              {isGenerating ? "AI is preparing questions..." : "Generate Smart Quiz ✨"}
            </button>
          </div>
        </div>
      )}

      {quizState === 'playing' && questions.length > 0 && (
        <div className="w-full max-w-2xl space-y-8 animate-in slide-in-from-bottom duration-500">
          <div className="flex justify-between items-center text-[10px] font-black text-brand-400 uppercase tracking-widest">
            <span>Question {currentIdx + 1} / {questions.length}</span>
            <span>Current Score: {score}</span>
          </div>
          <div className="glass-card p-12 rounded-[3.5rem] border-brand-200 shadow-2xl space-y-10">
            <h3 className="text-2xl font-black text-slate-800 dark:text-white leading-tight">{questions[currentIdx].question}</h3>
            <div className="grid gap-4">
              {questions[currentIdx].options.map((opt, i) => {
                const isCorrect = i === questions[currentIdx].correctAnswer;
                const isSelected = feedback === i;
                
                let btnStyle = "w-full text-left p-6 rounded-2xl border-2 transition-all font-bold ";
                if (feedback !== null) {
                  if (isCorrect) btnStyle += "bg-emerald-50 border-emerald-500 text-emerald-700";
                  else if (isSelected) btnStyle += "bg-red-50 border-red-500 text-red-700";
                  else btnStyle += "border-slate-100 opacity-50";
                } else {
                  btnStyle += "bg-white dark:bg-slate-900 border-brand-50 hover:border-brand-500 dark:text-white";
                }

                return (
                  <button key={i} onClick={() => handleSelect(i)} className={btnStyle}>
                    <div className="flex justify-between items-center">
                      <span>{opt}</span>
                      {feedback !== null && isCorrect && <span className="text-[10px] uppercase font-black tracking-widest text-emerald-500">Correct</span>}
                    </div>
                  </button>
                );
              })}
            </div>
            {feedback !== null && (
              <div className="p-6 bg-brand-50/50 rounded-2xl animate-in zoom-in duration-300 border border-brand-100">
                <p className="text-[10px] font-black uppercase text-brand-600 mb-1">Teacher's Note:</p>
                <p className="text-sm font-medium text-slate-600">{questions[currentIdx].explanation}</p>
              </div>
            )}
          </div>
        </div>
      )}

      {quizState === 'result' && (
        <div className="text-center space-y-8 animate-in zoom-in duration-500">
           <div className="text-8xl">🎓</div>
           <div>
              <h2 className="text-5xl font-black text-slate-800 dark:text-white tracking-tighter">Session Results</h2>
              <p className="text-xl font-bold text-brand-500 mt-2">You achieved {score} out of {questions.length} correct!</p>
           </div>
           <button onClick={() => {setQuizState('input'); setInputContent(''); setCurrentIdx(0); setScore(0);}} className="bg-brand-600 text-white px-12 py-5 rounded-3xl font-black uppercase text-xs tracking-widest shadow-2xl hover:scale-105 transition-all">Start New Challenge</button>
        </div>
      )}
    </div>
  );
};

export default SmartQuiz;
