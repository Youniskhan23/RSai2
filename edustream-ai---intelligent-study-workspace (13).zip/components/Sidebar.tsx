import React, { useState } from 'react';
import { AppTab } from '../types';

interface SidebarProps {
  activeTab: AppTab;
  setActiveTab: (tab: AppTab) => void;
  isDarkMode: boolean;
  toggleDarkMode: () => void;
  onAdjustFontSize: (delta: number) => void;
  fontSize: number;
}

const Sidebar: React.FC<SidebarProps> = ({ activeTab, setActiveTab, isDarkMode, toggleDarkMode, onAdjustFontSize, fontSize }) => {
  const [isOpen, setIsOpen] = useState(false);

  const menuSections = [
    {
      title: 'Main Hub',
      items: [
        { id: AppTab.DASHBOARD, label: 'Dashboard', icon: 'M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6' },
        { id: AppTab.STUDY_REPORT, label: 'Study Report', icon: 'M9 17v-2m3 2v-4m3 4v-6m2 10H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z' },
      ]
    },
    {
      title: 'Learning Zone',
      items: [
        { id: AppTab.STUDY_NOTES, label: 'Study Notes', icon: 'M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13C4.168 18.477 5.754 18 7.5 18s3.332.477 4.5 1.253m0-13C13.168 5.477 14.754 5 16.5 5c1.747 0 3.332.477 4.5 1.253v13C19.832 18.477 18.247 18 16.5 18c-1.746 0-3.332.477-4.5 1.253' },
        { id: AppTab.SMART_QUIZ, label: 'Smart Quiz', icon: 'M8.228 9c.549-1.165 2.03-2 3.772-2 2.21 0 4 1.343 4 3 0 1.4-1.278 2.575-3.006 2.907-.542.104-.994.54-.994 1.093m0 3h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z' },
        { id: AppTab.MINI_TEST, label: 'Daily Mini Test', icon: 'M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2m-6 9l2 2 4-4' },
        { id: AppTab.LIVE_TUTOR, label: 'Live Tutor', icon: 'M19 11a7 7 0 01-7 7m0 0a7 7 0 01-7-7m7 7v4m0 0H8m4 0h4m-4-8a3 3 0 01-3-3V5a3 3 0 116 0v6a3 3 0 01-3 3z' },
      ]
    },
    {
      title: 'AI Lab',
      items: [
        { id: AppTab.CHAT, label: 'AI Chat', icon: 'M8 10h.01M12 10h.01M16 10h.01M9 16H5a2 2 0 01-2-2V6a2 2 0 012-2h14a2 2 0 012 2v8a2 2 0 01-2 2h-5l-5 5v-5z' },
        { id: AppTab.FACT_CHECKER, label: 'Fact Checker', icon: 'M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z' },
        { id: AppTab.ANALYSIS_VAULT, label: 'Analysis Vault', icon: 'M20 7l-8-4-8 4m16 0l-8 4m8-4v10l-8 4m0-10L4 7m8 4v10M4 7v10l8 4' },
      ]
    },
    {
      title: 'Refresh & Utils',
      items: [
        { id: AppTab.REFRESHMENT, label: 'Fun Games', icon: 'M14.752 11.168l-3.197-2.132A1 1 0 0010 9.87v4.263a1 1 0 001.555.832l3.197-2.132a1 1 0 000-1.664z M21 12a9 9 0 11-18 0 9 9 0 0118 0z' },
        { id: AppTab.KIDS_STARTUP, label: 'Kids Startup', icon: 'M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1' },
        { id: AppTab.HISTORY, label: 'History', icon: 'M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z' },
        { id: AppTab.ARCHIVE, label: 'Archive', icon: 'M5 8h14M5 8a2 2 0 110-4h14a2 2 0 110 4M5 8v10a2 2 0 002 2h10a2 2 0 002-2V8m-9 4h4' },
      ]
    }
  ];

  return (
    <>
      <div className="lg:hidden flex items-center justify-between p-6 glass-card sticky top-0 z-50 shadow-md">
        <h1 className="text-4xl font-black gradient-text brand-logo-text">EduStream AI</h1>
        <div className="flex items-center space-x-3">
          <button onClick={toggleDarkMode} className="text-brand-400">
             <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
               {isDarkMode ? 
                 <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 3v1m0 16v1m9-9h-1M4 12H3m15.364-6.364l-.707.707M6.343 17.657l-.707.707m12.728 0l-.707-.707M6.343 6.343l-.707-.707M12 8a4 4 0 100 8 4 4 0 000-8z" /> : 
                 <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M20.354 15.354A9 9 0 018.646 3.646 9.003 9.003 0 0012 21a9.003 9.003 0 008.354-5.646z" />
               }
             </svg>
          </button>
          <button onClick={() => setIsOpen(!isOpen)} className="text-brand-400">
             <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d={isOpen ? "M6 18L18 6M6 6l12 12" : "M4 6h16M4 12h16M4 18h16"} /></svg>
          </button>
        </div>
      </div>

      <div className={`
        fixed inset-y-0 left-0 z-50 w-80 bg-white dark:bg-slate-950 border-r border-slate-100 dark:border-slate-900 
        transform transition-all duration-500 lg:translate-x-0 ease-in-out flex flex-col
        ${isOpen ? 'translate-x-0 shadow-2xl' : '-translate-x-full'}
      `}>
        <div className="p-10 pb-8">
          <h1 className="text-5xl font-black gradient-text brand-logo-text tracking-tighter leading-[0.85] mb-2">EduStream AI</h1>
          <div className="flex items-center space-x-1.5 mt-3">
             <div className="w-1.5 h-1.5 bg-brand-400 rounded-full animate-pulse shadow-sm"></div>
             <p className="text-[9px] font-black text-slate-400 dark:text-slate-600 uppercase tracking-widest">Active Workspace</p>
          </div>
        </div>
        
        <nav className="flex-1 px-5 py-4 space-y-7 overflow-y-auto hide-scrollbar">
          {menuSections.map((section, sIdx) => (
            <div key={sIdx} className="space-y-2">
              <h3 className="px-4 text-[9px] font-black text-slate-500 dark:text-slate-400 uppercase tracking-[0.25em] mb-3 opacity-90">{section.title}</h3>
              {section.items.map((item) => (
                <button
                  key={item.id}
                  onClick={() => { setActiveTab(item.id); setIsOpen(false); }}
                  className={`w-full flex items-center space-x-3 px-5 py-2.5 rounded-2xl transition-all duration-300 group ${
                    activeTab === item.id
                      ? 'bg-brand-50 text-brand-700 shadow-sm border border-brand-100/50'
                      : 'text-slate-500 dark:text-slate-400 hover:bg-brand-50/50 hover:text-brand-600 dark:hover:bg-slate-900'
                  }`}
                >
                  <svg className={`w-3.5 h-3.5 transition-transform group-hover:scale-110 ${activeTab === item.id ? 'text-brand-600' : ''}`} fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d={item.icon} />
                  </svg>
                  <span className="font-bold text-[12px]">{item.label}</span>
                </button>
              ))}
            </div>
          ))}
        </nav>

        <div className="p-5 border-t border-slate-100 dark:border-slate-900">
          <div className="bg-brand-50/50 dark:bg-slate-900/40 rounded-3xl p-5 border border-brand-100 dark:border-slate-800">
             <div className="flex items-center justify-between mb-4">
                <span className="text-[9px] font-black text-slate-500 uppercase tracking-[0.2em]">Interface</span>
                <button 
                  onClick={toggleDarkMode} 
                  className="relative w-11 h-11 bg-white dark:bg-slate-800 rounded-2xl flex items-center justify-center shadow-sm border border-slate-100 dark:border-slate-700 transition-all hover:scale-110 active:scale-95"
                >
                  <div className="relative overflow-hidden w-5 h-5">
                    <svg className={`absolute inset-0 w-5 h-5 text-yellow-400 transition-all duration-500 transform ${isDarkMode ? 'translate-y-8 opacity-0' : 'translate-y-0 opacity-100'}`} fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 3v1m0 16v1m9-9h-1M4 12H3m15.364-6.364l-.707.707M6.343 17.657l-.707.707m12.728 0l-.707-.707M6.343 6.343l-.707-.707M12 8a4 4 0 100 8 4 4 0 000-8z" />
                    </svg>
                    <svg className={`absolute inset-0 w-5 h-5 text-brand-300 transition-all duration-500 transform ${isDarkMode ? 'translate-y-0 opacity-100' : '-translate-y-8 opacity-0'}`} fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M20.354 15.354A9 9 0 018.646 3.646 9.003 9.003 0 0012 21a9.003 9.003 0 008.354-5.646z" />
                    </svg>
                  </div>
                </button>
             </div>
             <div className="flex items-center space-x-2">
                <button onClick={() => onAdjustFontSize(-1)} className="flex-1 py-1.5 bg-white dark:bg-slate-800 rounded-xl text-[10px] font-black border border-slate-200 dark:border-slate-700 shadow-sm transition-all hover:bg-slate-50">-</button>
                <div className="text-[10px] font-black text-brand-500 px-2">{fontSize}px</div>
                <button onClick={() => onAdjustFontSize(1)} className="flex-1 py-1.5 bg-white dark:bg-slate-800 rounded-xl text-[10px] font-black border border-slate-200 dark:border-slate-700 shadow-sm transition-all hover:bg-slate-50">+</button>
             </div>
          </div>
        </div>
      </div>
      {isOpen && <div className="fixed inset-0 bg-black/10 backdrop-blur-[2px] z-40 lg:hidden" onClick={() => setIsOpen(false)} />}
    </>
  );
};

export default Sidebar;