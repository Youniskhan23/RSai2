import React, { useState } from 'react';
import { GoogleGenAI, Type } from "@google/genai";
import { Language } from '../types';

interface AnalysisResult {
  concepts: string[];
  complexity: string;
  roadmap: string[];
  summary: string;
}

const AnalysisVault: React.FC = () => {
  const [text, setText] = useState('');
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [result, setResult] = useState<AnalysisResult | null>(null);
  const [lang, setLang] = useState<Language>('english');

  const runAnalysis = async () => {
    if (!text.trim()) return;
    setIsAnalyzing(true);
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || '' });

    try {
      const response = await ai.models.generateContent({
        model: "gemini-3-flash-preview",
        contents: `Deeply analyze this academic material: "${text}". Provide results in JSON format.`,
        config: {
          responseMimeType: "application/json",
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              concepts: { type: Type.ARRAY, items: { type: Type.STRING }, description: "List of core concepts" },
              complexity: { type: Type.STRING, description: "Beginner, Intermediate, or Advanced" },
              roadmap: { type: Type.ARRAY, items: { type: Type.STRING }, description: "3-step study plan" },
              summary: { type: Type.STRING, description: "A sharp 2-sentence summary" }
            },
            required: ["concepts", "complexity", "roadmap", "summary"]
          }
        }
      });

      const data = JSON.parse(response.text || "{}");
      setResult(data);
    } catch (e) {
      console.error(e);
      alert("Analysis failed. Try shorter text.");
    } finally {
      setIsAnalyzing(false);
    }
  };

  return (
    <div className="p-6 lg:p-12 max-w-6xl mx-auto space-y-10 animate-in fade-in duration-700">
      <header className="flex flex-col md:flex-row md:items-center justify-between gap-6">
        <div>
          <h2 className="text-3xl font-black text-slate-950 dark:text-white tracking-tighter uppercase">Analysis Vault</h2>
          <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mt-1">Deep Academic Processing Engine</p>
        </div>
      </header>

      <div className="grid grid-cols-1 lg:grid-cols-5 gap-8">
        <div className="lg:col-span-2 space-y-6">
          <div className="glass-card rounded-[3rem] p-8 border-brand-100 shadow-xl">
            <h3 className="text-sm font-black text-slate-800 dark:text-white uppercase tracking-widest mb-4">Input Material</h3>
            <textarea 
              className="w-full h-80 bg-slate-50 dark:bg-slate-900 border-2 border-transparent focus:border-brand-500 rounded-[2rem] p-6 text-sm outline-none transition-all dark:text-white resize-none font-bold"
              placeholder="Paste notes, research snippets, or complex paragraphs here..."
              value={text}
              onChange={(e) => setText(e.target.value)}
            />
            <button 
              onClick={runAnalysis}
              disabled={isAnalyzing || !text.trim()}
              className="w-full mt-6 bg-brand-600 hover:bg-brand-700 text-white py-4 rounded-2xl font-black uppercase text-xs tracking-widest shadow-xl shadow-brand-100 transition-all active:scale-95 disabled:opacity-50"
            >
              {isAnalyzing ? "Processing..." : "Decrypt & Analyze ✨"}
            </button>
          </div>
        </div>

        <div className="lg:col-span-3 space-y-6">
          {!result && !isAnalyzing ? (
            <div className="h-full flex flex-col items-center justify-center opacity-20 py-20">
              <div className="w-16 h-16 bg-brand-50 rounded-2xl flex items-center justify-center mb-4"><svg className="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" /></svg></div>
              <p className="text-[10px] font-black uppercase tracking-widest">Awaiting Content</p>
            </div>
          ) : isAnalyzing ? (
            <div className="space-y-6 animate-pulse">
              <div className="h-40 bg-brand-50 dark:bg-slate-900 rounded-[2.5rem]"></div>
              <div className="h-60 bg-brand-50 dark:bg-slate-900 rounded-[2.5rem]"></div>
            </div>
          ) : (
            <div className="space-y-6 animate-in zoom-in-95 duration-500">
              <div className="glass-card rounded-[2.5rem] p-8 border-brand-100 bg-brand-50/30">
                <span className="text-[10px] font-black text-brand-500 uppercase tracking-widest">AI Summary</span>
                <p className="text-lg font-black text-slate-800 dark:text-white mt-2 italic leading-snug">"{result.summary}"</p>
              </div>

              <div className="grid grid-cols-2 gap-6">
                <div className="glass-card rounded-[2.5rem] p-8 border-brand-100">
                  <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Complexity</span>
                  <p className="text-2xl font-black text-brand-600 mt-1">{result.complexity}</p>
                </div>
                <div className="glass-card rounded-[2.5rem] p-8 border-brand-100">
                  <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Core Concepts</span>
                  <div className="flex flex-wrap gap-2 mt-3">
                    {result.concepts.map((c, i) => (
                      <span key={i} className="px-3 py-1 bg-white dark:bg-slate-800 text-[10px] font-bold text-brand-500 rounded-lg shadow-sm border border-brand-50 uppercase tracking-tighter">{c}</span>
                    ))}
                  </div>
                </div>
              </div>

              <div className="glass-card rounded-[2.5rem] p-8 border-brand-100 space-y-4">
                <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Optimized Study Roadmap</span>
                <div className="space-y-3">
                  {result.roadmap.map((step, i) => (
                    <div key={i} className="flex items-center space-x-4 p-4 bg-white/60 dark:bg-slate-900 rounded-2xl border border-brand-50">
                      <div className="w-8 h-8 rounded-full bg-brand-500 text-white flex items-center justify-center text-xs font-black shadow-lg shadow-brand-100">{i + 1}</div>
                      <p className="text-sm font-bold text-slate-700 dark:text-slate-200">{step}</p>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default AnalysisVault;