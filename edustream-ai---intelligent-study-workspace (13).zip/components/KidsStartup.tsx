import React, { useState } from 'react';
import { getAIChatResponse } from '../services/geminiService';
import { Language } from '../types';

const KidsStartup: React.FC = () => {
  const [activeSubTab, setActiveSubTab] = useState<'ideas' | 'academy' | 'quiz' | 'game'>('academy');
  const [lang, setLang] = useState<Language>('english');
  const [idea, setIdea] = useState('');
  const [loading, setLoading] = useState(false);
  const [academyCategory, setAcademyCategory] = useState<'alphabets' | 'fruits' | 'colors' | 'body'>('alphabets');
  
  const [cash, setCash] = useState(100);
  const [inventory, setInventory] = useState(0);

  const content = {
    english: { 
      title: "Kids Startup Hub", 
      sub: "Learn business & basics while having fun!", 
      ideas: "Idea Generator", 
      academy: "Junior Academy",
      quiz: "Junior Quiz", 
      game: "Startup Game" 
    },
    urdu: { 
      title: "کڈز اسٹارٹ اپ ہب", 
      sub: "تفریح کے ساتھ بزنس اور بنیادی باتیں سیکھیں!", 
      ideas: "آئیڈیا جنریٹر", 
      academy: "جونیئر اکیڈمی",
      quiz: "جونیئر کوئز", 
      game: "اسٹارٹ اپ گیم" 
    },
    'roman-english': { 
      title: "Kids Startup Hub", 
      sub: "Mazy ke sath business aur basics seekhein!", 
      ideas: "Idea Generator", 
      academy: "Junior Academy",
      quiz: "Junior Quiz", 
      game: "Startup Game" 
    }
  };

  const academyData = {
    alphabets: [
      { item: 'A', label: 'Apple', icon: '🍎' }, { item: 'B', label: 'Ball', icon: '⚽' },
      { item: 'C', label: 'Cat', icon: '🐱' }, { item: 'D', label: 'Dog', icon: '🐶' },
      { item: 'E', label: 'Elephant', icon: '🐘' }, { item: 'F', label: 'Fish', icon: '🐟' }
    ],
    fruits: [
      { item: 'Apple', label: 'Saib', icon: '🍎' }, { item: 'Banana', label: 'Kela', icon: '🍌' },
      { item: 'Mango', label: 'Aam', icon: '🥭' }, { item: 'Grapes', label: 'Angoor', icon: '🍇' },
      { item: 'Orange', label: 'Malta', icon: '🍊' }, { item: 'Strawberry', label: 'Strawberry', icon: '🍓' }
    ],
    colors: [
      { item: 'Red', label: 'Laal', icon: '🔴' }, { item: 'Blue', label: 'Neela', icon: '🔵' },
      { item: 'Green', label: 'Hara', icon: '🟢' }, { item: 'Yellow', label: 'Peela', icon: '🟡' },
      { item: 'Pink', label: 'Gulabi', icon: '🌸' }, { item: 'Purple', label: 'Jamni', icon: '🟣' }
    ],
    body: [
      { item: 'Eyes', label: 'Ankhain', icon: '👀' }, { item: 'Ears', label: 'Kaan', icon: '👂' },
      { item: 'Hands', label: 'Hath', icon: '🙌' }, { item: 'Nose', label: 'Naak', icon: '👃' },
      { item: 'Mouth', label: 'Mun', icon: '👄' }, { item: 'Feet', label: 'Paon', icon: '👣' }
    ]
  };

  const generateIdea = async () => {
    setLoading(true);
    try {
      const res = await getAIChatResponse("Suggest a simple business idea for a 10 year old kid. Keep it fun and explain in 3 simple steps.", [], [], lang);
      setIdea(res);
    } catch (e) {
      setIdea("Error generating idea. Try again!");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="p-6 lg:p-10 space-y-8 animate-in fade-in duration-700 max-w-5xl mx-auto">
      <header className="flex flex-col md:flex-row md:items-center justify-between gap-6">
        <div>
          <h2 className={`text-3xl font-black text-slate-800 dark:text-white ${lang === 'urdu' ? 'urdu-text' : ''}`}>{content[lang].title}</h2>
          <p className={`text-sm text-slate-400 font-medium ${lang === 'urdu' ? 'urdu-text' : ''}`}>{content[lang].sub}</p>
        </div>
        <div className="flex bg-white dark:bg-slate-900 p-1.5 rounded-2xl shadow-sm border border-slate-100 dark:border-slate-800 self-start">
          {(['english', 'urdu', 'roman-english'] as Language[]).map(l => (
            <button key={l} onClick={() => setLang(l)} className={`px-4 py-1.5 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all ${lang === l ? 'bg-purple-400 text-white shadow-md' : 'text-slate-500 hover:text-purple-400'}`}>
              {l.replace('-english', '')}
            </button>
          ))}
        </div>
      </header>

      <div className="flex space-x-2 overflow-x-auto pb-2 hide-scrollbar">
        {(['academy', 'ideas', 'quiz', 'game'] as const).map(tab => (
          <button 
            key={tab} 
            onClick={() => setActiveSubTab(tab)}
            className={`px-6 py-3 rounded-2xl font-bold text-xs uppercase tracking-widest transition-all whitespace-nowrap ${activeSubTab === tab ? 'bg-purple-400 text-white shadow-lg shadow-purple-200/50' : 'bg-white dark:bg-slate-900 text-slate-500 dark:text-slate-400 border border-slate-100 dark:border-slate-800 hover:border-purple-200'}`}
          >
            {content[lang][tab]}
          </button>
        ))}
      </div>

      <div className="glass-card rounded-[3rem] p-8 lg:p-12 min-h-[500px] flex flex-col border-white/60">
        
        {activeSubTab === 'academy' && (
          <div className="space-y-8 animate-in fade-in duration-500">
            <div className="flex justify-center space-x-3 mb-6">
              {(['alphabets', 'fruits', 'colors', 'body'] as const).map(cat => (
                <button 
                  key={cat} 
                  onClick={() => setAcademyCategory(cat)}
                  className={`px-4 py-2 rounded-xl text-[10px] font-black uppercase tracking-widest border transition-all ${academyCategory === cat ? 'bg-brand-500 text-slate-900 border-brand-200 shadow-sm' : 'bg-white dark:bg-slate-800 text-slate-400 border-slate-100 dark:border-slate-700'}`}
                >
                  {cat}
                </button>
              ))}
            </div>
            
            <div className="grid grid-cols-2 md:grid-cols-3 gap-6">
              {academyData[academyCategory].map((d, i) => (
                <div key={i} className="bg-brand-50/50 dark:bg-slate-900/50 p-6 rounded-[2.5rem] border border-brand-100 dark:border-slate-800 text-center flex flex-col items-center hover:scale-105 transition-transform group">
                  <div className="text-4xl mb-3 group-hover:rotate-12 transition-transform">{d.icon}</div>
                  <h4 className="text-2xl font-black text-slate-800 dark:text-white">{d.item}</h4>
                  <p className="text-[10px] font-black text-brand-400 uppercase tracking-widest mt-1">{d.label}</p>
                </div>
              ))}
            </div>
          </div>
        )}

        {activeSubTab === 'ideas' && (
          <div className="flex-1 flex flex-col items-center justify-center text-center space-y-8 w-full max-w-2xl mx-auto animate-in zoom-in-95 duration-500">
             <div className="w-24 h-24 bg-purple-50 dark:bg-purple-900/30 rounded-full flex items-center justify-center mx-auto mb-4 text-4xl animate-bounce">💡</div>
             <h3 className="text-2xl font-black text-slate-800 dark:text-white">What's your next big idea?</h3>
             {idea ? (
               <div className={`p-8 bg-purple-50/50 dark:bg-slate-900/80 rounded-[2.5rem] text-left border border-purple-100/50 dark:border-slate-800 ${lang === 'urdu' ? 'urdu-text' : 'font-medium text-slate-600 dark:text-slate-300 shadow-inner'}`}>
                 {idea}
               </div>
             ) : <p className="text-slate-400 font-medium">Click below to generate a kid-friendly startup plan!</p>}
             <button onClick={generateIdea} disabled={loading} className="bg-purple-400 hover:bg-purple-500 text-white px-10 py-4 rounded-2xl font-black uppercase text-xs tracking-widest shadow-xl shadow-purple-300/20 active:scale-95 disabled:opacity-50 transition-all">
                {loading ? "Brainstorming..." : "Generate Magic Idea ✨"}
             </button>
          </div>
        )}

        {activeSubTab === 'quiz' && (
          <div className="flex-1 flex flex-col items-center justify-center space-y-8 animate-in zoom-in-95 duration-500 w-full max-w-lg mx-auto">
             <div className="w-20 h-20 bg-fuchsia-50 dark:bg-fuchsia-900/30 rounded-full flex items-center justify-center mx-auto text-3xl">❓</div>
             <div className="space-y-4 text-center">
                <h4 className="text-xl font-bold text-slate-800 dark:text-white">Junior Mini Quiz</h4>
                <p className="text-slate-400 text-sm max-w-md mx-auto italic">How much do you know about the world?</p>
             </div>
             <div className="grid gap-4 text-left w-full">
                {[
                  { q: "How many eyes do we have?", a: "Two (2)" },
                  { q: "How many days are in a week?", a: "Seven (7)" },
                  { q: "How many months are in a year?", a: "Twelve (12)" },
                  { q: "What is the color of an Apple?", a: "Red" }
                ].map((q, i) => (
                  <div key={i} className="bg-white/60 dark:bg-slate-900/60 p-6 rounded-3xl border border-purple-100/50 dark:border-slate-800 shadow-sm flex justify-between items-center group cursor-pointer hover:bg-white">
                     <div className="flex-1">
                        <p className="text-[10px] font-black text-purple-400 mb-1 uppercase tracking-widest">Question {i+1}</p>
                        <p className="text-sm font-bold text-slate-700 dark:text-white">{q.q}</p>
                     </div>
                     <div className="opacity-0 group-hover:opacity-100 transition-opacity bg-brand-500 text-slate-900 text-[10px] font-black px-3 py-1 rounded-lg uppercase">{q.a}</div>
                  </div>
                ))}
             </div>
          </div>
        )}

        {activeSubTab === 'game' && (
          <div className="flex-1 flex flex-col items-center justify-center space-y-10 animate-in zoom-in-95 duration-500 w-full max-w-md mx-auto">
             <div className="flex justify-between items-center w-full bg-purple-50 dark:bg-slate-900/60 p-8 rounded-[2.5rem] border border-purple-100/50 dark:border-slate-800 shadow-inner">
                <div className="text-left">
                   <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Savings</p>
                   <p className="text-3xl font-black text-purple-500">${cash}</p>
                </div>
                <div className="text-right">
                   <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Store Stock</p>
                   <p className="text-3xl font-black text-fuchsia-400">{inventory}</p>
                </div>
             </div>
             
             <div className="grid grid-cols-2 gap-4 w-full">
                <button 
                  onClick={() => { if(cash >= 10) { setCash(c => c-10); setInventory(i => i+1); }}}
                  className="bg-white/80 dark:bg-slate-900 p-8 rounded-[2rem] border border-purple-100 dark:border-slate-800 hover:ring-4 hover:ring-purple-50 transition-all group shadow-sm"
                >
                   <div className="text-3xl mb-3 group-hover:scale-125 transition-transform">📦</div>
                   <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Purchase</p>
                   <p className="text-xs font-bold text-purple-600">-$10</p>
                </button>
                <button 
                  onClick={() => { if(inventory > 0) { setInventory(i => i-1); setCash(c => c+25); }}}
                  className="bg-white/80 dark:bg-slate-900 p-8 rounded-[2rem] border border-fuchsia-100 dark:border-slate-800 hover:ring-4 hover:ring-fuchsia-50 transition-all group shadow-sm"
                >
                   <div className="text-3xl mb-3 group-hover:scale-125 transition-transform">💵</div>
                   <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Profit</p>
                   <p className="text-xs font-bold text-emerald-500">+$25</p>
                </button>
             </div>

             <div className="p-4 bg-amber-50/50 dark:bg-amber-900/20 rounded-2xl text-[10px] font-black text-amber-600 dark:text-amber-400 uppercase tracking-widest text-center w-full">
                Grow your capital to open new stores!
             </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default KidsStartup;