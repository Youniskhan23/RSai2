import React, { useEffect, useState } from 'react';
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { AppTab, Language } from '../types';

const Dashboard: React.FC<{ onNavigate: (tab: AppTab) => void }> = ({ onNavigate }) => {
  const [stats, setStats] = useState({ chats: 0, facts: 0, notes: 0, studyFactor: 85 });
  const [lang, setLang] = useState<Language>('english');
  const [quickQuestion, setQuickQuestion] = useState({ q: "What is the heart of a computer?", a: "CPU", show: false });

  const itQuestions = [
    { q: "What does RAM stand for?", a: "Random Access Memory" },
    { q: "Which protocol is for secure web browsing?", a: "HTTPS" },
    { q: "Who invented the World Wide Web?", a: "Tim Berners-Lee" },
    { q: "What is the primary language for AI?", a: "Python" }
  ];

  useEffect(() => {
    const c = JSON.parse(localStorage.getItem('chat_history') || '[]').length;
    const f = JSON.parse(localStorage.getItem('fact_history') || '[]').length;
    const n = JSON.parse(localStorage.getItem('study_notes') || '[]').length;
    setStats({ chats: c, facts: f, notes: n, studyFactor: 75 + Math.floor(Math.random() * 20) });
  }, []);

  const changeQuestion = () => {
    const rand = itQuestions[Math.floor(Math.random() * itQuestions.length)];
    setQuickQuestion({ ...rand, show: false });
  };

  const content = {
    english: { title: "Hi,", sub: "Your personalized study hub is ready.", factor: "Study Score", report: "Learning Trends", quick: "Quick Test" },
    urdu: { title: "ہیلو،", sub: "آپ کا اسٹڈی مرکز تیار ہے۔", factor: "اسٹڈی سکور", report: "سیکھنے کا رجحان", quick: "فوری ٹیسٹ" },
    'roman-english': { title: "Hi,", sub: "Aapka workspace active hai.", factor: "Study Score", report: "Activity Trends", quick: "Quick Test" }
  };

  const chartData = [
    {n:'M', a:30},
    {n:'T', a:55},
    {n:'W', a:40},
    {n:'T', a:80},
    {n:'F', a:60},
    {n:'S', a:95},
    {n:'S', a:70}
  ];

  return (
    <div className="p-6 lg:p-12 space-y-10 animate-in fade-in duration-1000">
      <header className="flex flex-col md:flex-row md:items-center justify-between gap-6">
        <div className="space-y-1">
          <h2 className={`text-5xl font-black text-slate-950 dark:text-white tracking-tighter ${lang === 'urdu' ? 'urdu-text' : ''}`}>
            {content[lang].title} <span className="gradient-text">Ready to Shine?</span>
          </h2>
          <p className={`text-slate-600 dark:text-slate-400 font-extrabold uppercase tracking-widest text-[10px] ${lang === 'urdu' ? 'urdu-text' : ''}`}>{content[lang].sub}</p>
        </div>
        <div className="flex bg-white dark:bg-slate-900 p-1.5 rounded-2xl shadow-sm border border-brand-200 dark:border-slate-800 self-start">
          {(['english', 'urdu', 'roman-english'] as Language[]).map(l => (
            <button key={l} onClick={() => setLang(l)} className={`px-4 py-2 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all ${lang === l ? 'bg-brand-500 text-slate-900 shadow-sm' : 'text-brand-300 hover:text-brand-500'}`}>
              {l.replace('-english', '')}
            </button>
          ))}
        </div>
      </header>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2 space-y-8">
          <div className="glass-card rounded-[3rem] p-10 space-y-8 border-brand-100 shadow-xl">
            <div className="flex items-center justify-between">
              <h3 className={`text-xl font-black text-slate-950 dark:text-white uppercase tracking-tight ${lang === 'urdu' ? 'urdu-text' : ''}`}>{content[lang].report}</h3>
              <button onClick={() => onNavigate(AppTab.STUDY_REPORT)} className="text-[10px] font-black text-brand-500 uppercase tracking-widest hover:underline">Full Analytics</button>
            </div>
            <div className="h-[280px] w-full">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={chartData}>
                  <defs><linearGradient id="c" x1="0" y1="0" x2="0" y2="1"><stop offset="5%" stopColor="#e9e4ff" stopOpacity={0.4}/><stop offset="95%" stopColor="#e9e4ff" stopOpacity={0}/></linearGradient></defs>
                  <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f4f1ff" className="dark:opacity-5" />
                  <XAxis dataKey="n" axisLine={false} tickLine={false} tick={{fill: '#c1b5ff', fontSize: 10, fontWeight: 900}} />
                  <Tooltip contentStyle={{ borderRadius: '24px', border: 'none', background: 'rgba(255,255,255,0.95)', boxShadow: '0 10px 25px -5px rgba(229,225,255,0.2)' }} />
                  <Area type="monotone" dataKey="a" stroke="#c1b5ff" strokeWidth={6} fillOpacity={1} fill="url(#c)" />
                </AreaChart>
              </ResponsiveContainer>
            </div>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
            {[
              { id: AppTab.MINI_TEST, label: 'Quiz', color: 'bg-brand-300', icon: 'M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2' },
              { id: AppTab.REFRESHMENT, label: 'Games', color: 'bg-fuchsia-50', icon: 'M13 10V3L4 14h7v7l9-11h-7z' },
              { id: AppTab.FACT_CHECKER, label: 'Fact', color: 'bg-emerald-50', icon: 'M9 12l2 2 4-4m6 2a9 9 0 11-18 0' },
              { id: AppTab.CHAT, label: 'Chat', color: 'bg-indigo-50', icon: 'M8 10h.01M12 10h.01M16 10h.01' },
            ].map((f, i) => (
              <button key={i} onClick={() => onNavigate(f.id)} className="glass-card p-5 rounded-[2.5rem] flex flex-col items-center space-y-2.5 group hover:-translate-y-1 transition-all border-brand-50">
                <div className={`w-8 h-8 ${f.color} rounded-lg flex items-center justify-center text-slate-900 group-hover:rotate-6 transition-transform shadow-sm`}>
                  <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d={f.icon} /></svg>
                </div>
                <span className="text-[9px] font-black text-slate-800 dark:text-slate-400 uppercase tracking-widest">{f.label}</span>
              </button>
            ))}
          </div>
        </div>

        <div className="space-y-8">
          <div className="glass-card rounded-[3rem] p-10 flex flex-col items-center text-center space-y-6 border-brand-100 shadow-xl">
             <div className="relative w-36 h-36 flex items-center justify-center">
                <svg viewBox="0 0 100 100" className="w-full h-full transform -rotate-90">
                  <circle cx="50" cy="50" r="44" strokeWidth="10" stroke="currentColor" fill="transparent" className="text-brand-50 dark:text-slate-800" />
                  <circle cx="50" cy="50" r="44" strokeWidth="10" stroke="#c1b5ff" fill="transparent" strokeDasharray="276" strokeDashoffset={276 - (276 * stats.studyFactor) / 100} strokeLinecap="round" />
                </svg>
                <div className="absolute inset-0 flex items-center justify-center font-black text-3xl text-brand-700 dark:text-white">{stats.studyFactor}</div>
             </div>
             <div>
                <h4 className={`text-xs font-black text-slate-600 uppercase tracking-[0.3em] ${lang === 'urdu' ? 'urdu-text' : ''}`}>{content[lang].factor}</h4>
                <p className="text-[10px] text-brand-400 font-bold mt-2 uppercase tracking-widest">Active Level: Master</p>
             </div>
          </div>

          <div className="bg-brand-200 rounded-[3rem] p-10 text-slate-900 shadow-2xl shadow-brand-100 space-y-6 animate-in slide-in-from-right duration-500">
             <div className="flex justify-between items-center">
                <h4 className="text-xs font-black uppercase tracking-[0.2em] opacity-80">{content[lang].quick}</h4>
                <button onClick={changeQuestion} className="text-[10px] font-black hover:scale-110 transition-transform">REFRESH</button>
             </div>
             <div className="space-y-4">
                <p className="text-sm font-black opacity-90 italic">"{quickQuestion.q}"</p>
                {quickQuestion.show ? (
                  <p className="text-2xl font-black bg-white/60 p-4 rounded-2xl animate-in fade-in zoom-in duration-300">{quickQuestion.a}</p>
                ) : (
                  <button onClick={() => setQuickQuestion({ ...quickQuestion, show: true })} className="w-full bg-white text-slate-900 py-3 rounded-2xl font-black text-[10px] uppercase tracking-widest active:scale-95 transition-all shadow-sm">Reveal Answer</button>
                )}
             </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;