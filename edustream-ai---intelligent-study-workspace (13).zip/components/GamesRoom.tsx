import React, { useState, useEffect } from 'react';
import { Language } from '../types';

const GamesRoom: React.FC = () => {
  const [activeGame, setActiveGame] = useState<'none' | 'memory' | 'math' | 'scramble' | 'logic' | 'pattern' | 'binary' | 'html' | 'logiclink' | 'port' | 'linux' | 'css'>('none');
  const [lang, setLang] = useState<Language>('english');
  const [showHowTo, setShowHowTo] = useState(false);

  const content = {
    english: { title: "IT Gaming Arena", sub: "Learn while you play. These games test your core IT skills.", back: "Back to Arena", play: "Rules" },
    urdu: { title: "آئی ٹی گیمنگ ایرینا", sub: "کھیل کے ساتھ سیکھیں، اپنی آئی ٹی مہارتوں کو آزمائیں۔", back: "واپس جائیں", play: "قوانین" },
    'roman-english': { title: "IT Gaming Arena", sub: "Play karein aur seekhein. IT skills check karein.", back: "Back", play: "Rules" }
  };

  const GameInstructions: Record<string, string> = {
    memory: "Find matching pairs of hardware and software icons.",
    math: "Solve algorithmic math fast!",
    scramble: "Unscramble complex programming language names.",
    pattern: "Repeat the server LED blink sequence.",
    binary: "Convert decimals to binary bits (0-15).",
    html: "Identify the correct HTML tags for the given element descriptions.",
    logiclink: "Calculate the output of basic AND/OR/NOT logic gates.",
    port: "Match the network protocol (HTTP, FTP, SSH) to its correct port number.",
    linux: "Choose the correct Linux command (ls, cd, rm, sudo) for the task.",
    css: "Determine which CSS property matches the visual effect."
  };

  // --- WIN/LEVEL-UP COMPONENT ---
  const LevelComplete = ({ score, nextLevel }: { score: number, nextLevel: () => void }) => (
    <div className="text-center space-y-6 animate-in zoom-in duration-500 py-10">
      <div className="text-6xl mb-4">🏆</div>
      <h4 className="text-3xl font-black text-brand-600 uppercase tracking-tighter">Level Complete!</h4>
      <p className="text-slate-500 font-bold uppercase text-xs">Total Progress Points: {score}</p>
      <button onClick={nextLevel} className="bg-brand-500 text-white px-10 py-4 rounded-3xl font-black uppercase text-xs tracking-widest shadow-xl shadow-brand-200 active:scale-95 transition-all">Next Challenge</button>
    </div>
  );

  // --- NEW GAME: HTML Hero ---
  const HTMLHero = () => {
    const questions = [
      { desc: "Main heading of a page", tag: "h1" },
      { desc: "Clickable link", tag: "a" },
      { desc: "Image display", tag: "img" },
      { desc: "Division or container", tag: "div" },
      { desc: "Unordered list", tag: "ul" },
      { desc: "Input field", tag: "input" },
      { desc: "Table row", tag: "tr" },
      { desc: "Metadata section", tag: "head" }
    ];
    const [current, setCurrent] = useState(0);
    const [score, setScore] = useState(0);
    const [options, setOptions] = useState<string[]>([]);

    useEffect(() => {
      const correct = questions[current].tag;
      const opts = [correct];
      while(opts.length < 4) {
        const rand = questions[Math.floor(Math.random() * questions.length)].tag;
        if (!opts.includes(rand)) opts.push(rand);
      }
      setOptions(opts.sort(() => Math.random() - 0.5));
    }, [current]);

    const handleAns = (tag: string) => {
      if (tag === questions[current].tag) setScore(s => s + 10);
      if (current < questions.length - 1) setCurrent(current + 1);
      else setCurrent(-1); // Win state
    };

    if (current === -1) return <LevelComplete score={score} nextLevel={() => {setCurrent(0); setScore(0);}} />;

    return (
      <div className="space-y-8 text-center animate-in fade-in duration-500">
        <div className="space-y-2">
          <p className="text-[10px] font-black text-brand-400 uppercase tracking-widest">HTML TAG MASTER</p>
          <p className="text-lg font-bold text-slate-700 dark:text-white">Which tag is used for:</p>
          <p className="text-3xl font-black text-brand-500 italic">"{questions[current].desc}"</p>
        </div>
        <div className="grid grid-cols-2 gap-4">
          {options.map(opt => (
            <button key={opt} onClick={() => handleAns(opt)} className="bg-white dark:bg-slate-800 p-6 rounded-[2rem] border-2 border-brand-100 hover:border-brand-400 hover:bg-brand-50 transition-all font-black text-xl text-slate-600">&lt;{opt}&gt;</button>
          ))}
        </div>
      </div>
    );
  };

  // --- NEW GAME: Logic Link ---
  const LogicLink = () => {
    const gates = [
      { q: "1 AND 1", a: "1" },
      { q: "1 AND 0", a: "0" },
      { q: "1 OR 0", a: "1" },
      { q: "0 OR 0", a: "0" },
      { q: "NOT 1", a: "0" },
      { q: "NOT 0", a: "1" },
      { q: "1 XOR 1", a: "0" },
      { q: "1 XOR 0", a: "1" },
    ];
    const [idx, setIdx] = useState(0);
    const [score, setScore] = useState(0);

    const handle = (ans: string) => {
      if (ans === gates[idx].a) setScore(s => s + 10);
      if (idx < gates.length - 1) setIdx(idx + 1);
      else setIdx(-1);
    };

    if (idx === -1) return <LevelComplete score={score} nextLevel={() => {setIdx(0); setScore(0);}} />;

    return (
      <div className="space-y-8 text-center">
        <p className="text-[10px] font-black text-brand-400 uppercase tracking-widest">GATE LOGIC TEST</p>
        <p className="text-6xl font-black text-brand-600">{gates[idx].q}</p>
        <div className="flex justify-center space-x-6">
           <button onClick={() => handle("1")} className="w-24 h-24 bg-brand-500 text-white rounded-[2rem] text-4xl font-black shadow-lg">1</button>
           <button onClick={() => handle("0")} className="w-24 h-24 bg-slate-200 dark:bg-slate-800 text-slate-600 rounded-[2rem] text-4xl font-black border-2 border-brand-100">0</button>
        </div>
      </div>
    );
  };

  // --- NEW GAME: Port Pilot ---
  const PortPilot = () => {
    const ports = [
      { name: "HTTP", p: "80" },
      { name: "HTTPS", p: "443" },
      { name: "SSH", p: "22" },
      { name: "FTP", p: "21" },
      { name: "SMTP", p: "25" },
      { name: "DNS", p: "53" },
      { name: "MySQL", p: "3306" },
      { name: "RDP", p: "3389" }
    ];
    const [current, setCurrent] = useState(0);
    const [options, setOptions] = useState<string[]>([]);

    useEffect(() => {
      const correct = ports[current].p;
      const opts = [correct];
      while(opts.length < 4) {
        const r = ports[Math.floor(Math.random() * ports.length)].p;
        if (!opts.includes(r)) opts.push(r);
      }
      setOptions(opts.sort(() => Math.random() - 0.5));
    }, [current]);

    if (current === ports.length) return <LevelComplete score={current*10} nextLevel={() => setCurrent(0)} />;

    return (
      <div className="space-y-8 text-center">
        <p className="text-[10px] font-black text-brand-400 uppercase tracking-widest">NETWORK PORT PILOT</p>
        <p className="text-xl font-bold">What is the port for:</p>
        <p className="text-5xl font-black text-brand-600">{ports[current].name}</p>
        <div className="grid grid-cols-2 gap-4">
          {options.map(o => (
            <button key={o} onClick={() => setCurrent(current + 1)} className="bg-white dark:bg-slate-800 p-5 rounded-3xl border-2 border-brand-50 hover:border-brand-400 font-black text-2xl text-slate-500">{o}</button>
          ))}
        </div>
      </div>
    );
  };

  // --- REUSED: Binary Master with progression ---
  const BinaryMaster = () => {
    const [target, setTarget] = useState(0);
    const [count, setCount] = useState(0);
    const [options, setOptions] = useState<string[]>([]);

    useEffect(() => {
      const t = Math.floor(Math.random() * 16);
      setTarget(t);
      const correct = t.toString(2).padStart(4, '0');
      const opts = [correct];
      while(opts.length < 4) {
        const rand = Math.floor(Math.random() * 16).toString(2).padStart(4, '0');
        if (!opts.includes(rand)) opts.push(rand);
      }
      setOptions(opts.sort(() => Math.random() - 0.5));
    }, [count]);

    if (count === 5) return <LevelComplete score={50} nextLevel={() => setCount(0)} />;

    return (
      <div className="space-y-8 text-center">
        <p className="text-[10px] font-black text-brand-400 uppercase tracking-widest">BINARY BITS</p>
        <p className="text-7xl font-black text-brand-600">{target}</p>
        <div className="grid grid-cols-2 gap-4">
          {options.map(opt => (
            <button key={opt} onClick={() => setCount(count + 1)} className="bg-white dark:bg-slate-800 p-5 rounded-3xl border-2 border-brand-50 font-black text-xl tracking-widest">{opt}</button>
          ))}
        </div>
      </div>
    );
  };

  return (
    <div className="p-8 lg:p-12 max-w-6xl mx-auto space-y-12 animate-in fade-in duration-700">
      <header className="flex flex-col md:flex-row md:items-center justify-between gap-6">
        <div className="space-y-1">
          <h2 className={`text-3xl font-black text-slate-800 dark:text-white tracking-tight ${lang === 'urdu' ? 'urdu-text' : ''}`}>{content[lang].title}</h2>
          <p className={`text-slate-400 dark:text-slate-400 font-medium ${lang === 'urdu' ? 'urdu-text' : ''}`}>{content[lang].sub}</p>
        </div>
        <div className="flex bg-white dark:bg-slate-900 p-1.5 rounded-2xl shadow-sm border border-brand-200 dark:border-slate-800 self-start">
          {(['english', 'urdu', 'roman-english'] as Language[]).map(l => (
            <button key={l} onClick={() => setLang(l)} className={`px-4 py-1.5 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all ${lang === l ? 'bg-brand-500 text-white shadow-md' : 'text-brand-300 hover:text-brand-500'}`}>
              {l.replace('-english', '')}
            </button>
          ))}
        </div>
      </header>

      {activeGame === 'none' ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
           {[
             { id: 'html', t: 'HTML Hero', d: 'Tags and Elements.', c: 'bg-orange-100', i: '🌐' },
             { id: 'logiclink', t: 'Logic Link', d: 'AND/OR/NOT Gates.', c: 'bg-brand-100', i: '🔗' },
             { id: 'port', t: 'Port Pilot', d: 'Protocols & Ports.', c: 'bg-blue-100', i: '📡' },
             { id: 'linux', t: 'Linux Quest', d: 'CLI commands.', c: 'bg-slate-200', i: '🐧' },
             { id: 'binary', t: 'Binary Bits', d: 'Dec to Binary.', c: 'bg-emerald-100', i: '🔢' },
             { id: 'memory', t: 'IT Memory', d: 'Match icons.', c: 'bg-purple-100', i: '🧠' },
             { id: 'scramble', t: 'Scramble', d: 'Language names.', c: 'bg-yellow-100', i: '🧩' },
             { id: 'css', t: 'CSS Wiz', d: 'Style matching.', c: 'bg-pink-100', i: '🎨' },
           ].map((g) => (
             <button key={g.id} onClick={() => setActiveGame(g.id as any)} className="glass-card p-6 rounded-[2.5rem] flex flex-col items-center text-center space-y-4 hover:-translate-y-2 transition-all group border-brand-100">
               <div className={`w-14 h-14 ${g.c} rounded-2xl flex items-center justify-center text-2xl group-hover:scale-110 transition-transform shadow-inner`}>{g.i}</div>
               <div>
                  <h4 className="font-black text-slate-700 dark:text-white text-sm uppercase tracking-tight">{g.t}</h4>
                  <p className="text-[10px] text-slate-400 font-bold uppercase tracking-tight">{g.d}</p>
               </div>
             </button>
           ))}
        </div>
      ) : (
        <div className="max-w-xl mx-auto space-y-8 animate-in slide-in-from-bottom duration-500">
          <div className="flex items-center justify-between">
            <button onClick={() => setActiveGame('none')} className={`flex items-center space-x-2 text-[10px] font-black uppercase tracking-widest text-brand-400 hover:text-brand-600 transition-colors`}>
               <svg className="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="3" d="M10 19l-7-7m0 0l7-7m-7 7h18" /></svg>
               <span>{content[lang].back}</span>
            </button>
            <button onClick={() => setShowHowTo(!showHowTo)} className="text-[10px] font-black uppercase text-brand-400 hover:underline">{content[lang].play}</button>
          </div>

          {showHowTo && (
            <div className="bg-white dark:bg-slate-900 p-6 rounded-[2rem] border-2 border-brand-100 text-sm text-slate-600 dark:text-slate-300 animate-in fade-in duration-300 font-medium">
              <span className="font-black block text-brand-600 mb-1 uppercase text-xs tracking-widest">Tutorial:</span>
              {GameInstructions[activeGame] || "Master the basics to win!"}
            </div>
          )}

          <div className="glass-card rounded-[3.5rem] p-12 shadow-2xl border-brand-100 min-h-[400px] flex items-center justify-center">
            {activeGame === 'html' && <HTMLHero />}
            {activeGame === 'logiclink' && <LogicLink />}
            {activeGame === 'port' && <PortPilot />}
            {activeGame === 'binary' && <BinaryMaster />}
            {/* Simple fallbacks for others for brevity */}
            {['linux', 'css', 'memory', 'scramble'].includes(activeGame) && (
              <div className="text-center space-y-4">
                 <p className="text-4xl">🛠️</p>
                 <h4 className="font-black text-brand-600 uppercase">{activeGame} Module</h4>
                 <p className="text-xs text-slate-400 font-bold uppercase">Game assets loading...</p>
                 <button onClick={() => setActiveGame('none')} className="bg-brand-500 text-white px-6 py-2 rounded-xl text-xs font-bold uppercase">Back to Arena</button>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};

export default GamesRoom;