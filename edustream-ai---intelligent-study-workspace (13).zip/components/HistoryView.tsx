
import React, { useState, useEffect } from 'react';
import { FactCheckHistoryItem, ChatHistoryItem } from '../types';

const HistoryView: React.FC = () => {
  const [factHistory, setFactHistory] = useState<FactCheckHistoryItem[]>([]);
  const [chatHistory, setChatHistory] = useState<ChatHistoryItem[]>([]);

  useEffect(() => {
    setFactHistory(JSON.parse(localStorage.getItem('fact_history') || '[]'));
    setChatHistory(JSON.parse(localStorage.getItem('chat_history') || '[]'));
  }, []);

  const clearHistory = () => {
    if (confirm("Clear all history? This cannot be undone.")) {
      localStorage.removeItem('fact_history');
      localStorage.removeItem('chat_history');
      setFactHistory([]);
      setChatHistory([]);
    }
  };

  return (
    <div className="p-4 lg:p-8 h-full max-w-5xl mx-auto space-y-8 animate-in fade-in duration-500">
      <header className="flex items-center justify-between">
        <div>
          <h2 className="text-3xl font-bold text-slate-800 dark:text-slate-100">Activity History</h2>
          <p className="text-sm text-slate-500 dark:text-slate-400">Everything you've checked or chatted about.</p>
        </div>
        <button 
          onClick={clearHistory}
          className="text-xs font-bold text-red-500 hover:underline"
        >
          Clear All
        </button>
      </header>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        <section className="space-y-4">
          <h3 className="text-lg font-bold flex items-center space-x-2">
            <span className="w-2 h-2 bg-indigo-500 rounded-full"></span>
            <span>AI Chats</span>
          </h3>
          <div className="space-y-3">
            {chatHistory.length === 0 ? <p className="text-sm text-slate-400 italic">No chat history.</p> : 
              chatHistory.map((item) => (
                <div key={item.id} className="glass p-4 rounded-2xl border border-slate-100 dark:border-slate-800 hover:border-indigo-200 transition-all">
                  <div className="flex justify-between items-start mb-2">
                    <span className="text-[10px] bg-slate-100 dark:bg-slate-700 px-2 py-0.5 rounded uppercase font-bold text-slate-500">
                      {item.language}
                    </span>
                    <span className="text-[10px] text-slate-400">{item.timestamp}</span>
                  </div>
                  <p className="text-sm text-slate-700 dark:text-slate-300 font-medium line-clamp-2 italic">"{item.preview}"</p>
                </div>
              ))
            }
          </div>
        </section>

        <section className="space-y-4">
          <h3 className="text-lg font-bold flex items-center space-x-2">
            <span className="w-2 h-2 bg-purple-500 rounded-full"></span>
            <span>Fact Checks</span>
          </h3>
          <div className="space-y-3">
            {factHistory.length === 0 ? <p className="text-sm text-slate-400 italic">No verification history.</p> : 
              factHistory.map((item) => (
                <div key={item.id} className="glass p-4 rounded-2xl border border-slate-100 dark:border-slate-800 hover:border-purple-200 transition-all">
                  <div className="flex justify-between items-center mb-2">
                    <div className="flex items-center space-x-2">
                      <div className="w-8 h-8 rounded-full flex items-center justify-center text-[10px] font-black border-2" style={{ borderColor: item.score > 70 ? '#10b981' : item.score > 40 ? '#f59e0b' : '#ef4444' }}>
                        {item.score}
                      </div>
                      <span className="text-xs font-black uppercase tracking-tighter" style={{ color: item.score > 70 ? '#10b981' : item.score > 40 ? '#f59e0b' : '#ef4444' }}>
                        {item.verdict}
                      </span>
                    </div>
                    <span className="text-[10px] text-slate-400">{item.timestamp}</span>
                  </div>
                  <p className="text-sm text-slate-700 dark:text-slate-300 line-clamp-2">"{item.statement}"</p>
                </div>
              ))
            }
          </div>
        </section>
      </div>
    </div>
  );
};

export default HistoryView;
