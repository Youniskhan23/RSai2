
import React, { useState } from 'react';

type Subject = 'IT' | 'Science' | 'General' | 'Daily Life' | 'Math' | 'History' | 'Islam' | 'Geography' | 'Sports';

const MiniTest: React.FC = () => {
  const [step, setStep] = useState<'start' | 'select' | 'playing' | 'end'>('start');
  const [subject, setSubject] = useState<Subject>('IT');
  const [currentQ, setCurrentQ] = useState(0);
  const [score, setScore] = useState(0);
  const [feedback, setFeedback] = useState<{ isCorrect: boolean; show: boolean } | null>(null);

  const questionBank: Record<Subject, { q: string; options: string[]; correct: number; explanation: string }[]> = {
    IT: [
      { q: "What does 'CPU' stand for?", options: ["Central Process Unit", "Central Processing Unit", "Computer Power Unit"], correct: 1, explanation: "CPU is the primary component of a computer that performs most processing." },
      { q: "What is 101 in Binary?", options: ["3", "5", "7"], correct: 1, explanation: "1*2^2 + 0*2^1 + 1*2^0 = 4 + 0 + 1 = 5." },
      { q: "Which of these is an Operating System?", options: ["Python", "Linux", "HTML"], correct: 1, explanation: "Linux is a kernel that powers many operating systems." },
      { q: "What does HTTP stand for?", options: ["Hypertext Transfer Protocol", "High Text Tech Process", "Hyperlink Today Tool"], correct: 0, explanation: "HTTP is the protocol used for transmitting web pages." },
      { q: "Who is the founder of Microsoft?", options: ["Steve Jobs", "Bill Gates", "Mark Zuckerberg"], correct: 1, explanation: "Bill Gates and Paul Allen founded Microsoft in 1975." },
      { q: "What is the primary language for Android apps?", options: ["Swift", "Kotlin", "C#"], correct: 1, explanation: "Kotlin is now the preferred language for Android development." }
    ],
    Science: [
      { q: "Which planet is known as the Red Planet?", options: ["Venus", "Mars", "Jupiter"], correct: 1, explanation: "Mars has iron oxide on its surface giving it a reddish look." },
      { q: "What is the chemical symbol for Gold?", options: ["Gd", "Ag", "Au"], correct: 2, explanation: "Au comes from the Latin word 'Aurum'." },
      { q: "What gas do plants absorb from the air?", options: ["Oxygen", "Carbon Dioxide", "Nitrogen"], correct: 1, explanation: "Plants use CO2 for photosynthesis." },
      { q: "How many bones are in the adult human body?", options: ["106", "206", "306"], correct: 1, explanation: "Adults typically have 206 bones." },
      { q: "What is the speed of light?", options: ["300,000 km/s", "150,000 km/s", "1,000,000 km/s"], correct: 0, explanation: "Light travels at approximately 300,000 kilometers per second in a vacuum." },
      { q: "Which part of the cell is the powerhouse?", options: ["Nucleus", "Ribosome", "Mitochondria"], correct: 2, explanation: "Mitochondria generate most of the cell's supply of ATP." }
    ],
    Math: [
      { q: "What is the square root of 144?", options: ["10", "12", "14"], correct: 1, explanation: "12 * 12 = 144." },
      { q: "What is 7 multiplied by 8?", options: ["54", "56", "58"], correct: 1, explanation: "7 * 8 = 56." },
      { q: "What is the value of Pi (to 2 decimals)?", options: ["3.12", "3.14", "3.16"], correct: 1, explanation: "Pi is approximately 3.14159..." },
      { q: "A triangle with all sides equal is called?", options: ["Isosceles", "Equilateral", "Scalene"], correct: 1, explanation: "Equilateral triangles have 3 equal sides and angles." },
      { q: "What is 15% of 200?", options: ["20", "30", "40"], correct: 1, explanation: "0.15 * 200 = 30." },
      { q: "Solve: 2 + 2 * 2", options: ["6", "8", "4"], correct: 0, explanation: "Follow BODMAS: Multiply first (2*2=4), then add (2+4=6)." }
    ],
    Islam: [
      { q: "How many pillars of Islam are there?", options: ["4", "5", "6"], correct: 1, explanation: "The five pillars are Shahada, Salah, Zakat, Sawm, and Hajj." },
      { q: "In which month was the Quran revealed?", options: ["Rajab", "Ramadan", "Shaban"], correct: 1, explanation: "The Quran was first revealed during the month of Ramadan." },
      { q: "Which Prophet built the Ark?", options: ["Ibrahim", "Nuh", "Musa"], correct: 1, explanation: "Prophet Nuh (A.S) built the Ark by Allah's command." },
      { q: "What is the direction of Qibla?", options: ["Madinah", "Jerusalem", "Makkah (Kaaba)"], correct: 2, explanation: "Muslims face the Kaaba in Makkah for prayers." },
      { q: "How many times a day do Muslims pray?", options: ["3", "5", "7"], correct: 1, explanation: "Fajr, Dhuhr, Asr, Maghrib, and Isha are the 5 obligatory prayers." },
      { q: "Who was the first Caliph of Islam?", options: ["Umar ibn al-Khattab", "Abu Bakr as-Siddiq", "Ali ibn Abi Talib"], correct: 1, explanation: "Abu Bakr (R.A) was the first Caliph after the Prophet (S.A.W)." }
    ],
    General: [
      { q: "Who wrote 'Romeo and Juliet'?", options: ["Mark Twain", "William Shakespeare", "Charles Dickens"], correct: 1, explanation: "It's one of Shakespeare's most famous tragedies." },
      { q: "Which is the largest ocean?", options: ["Atlantic", "Indian", "Pacific"], correct: 2, explanation: "The Pacific Ocean covers about 30% of the Earth's surface." },
      { q: "Which country has the largest population?", options: ["USA", "India", "China"], correct: 1, explanation: "India surpassed China in 2023 as the most populous country." },
      { q: "What is the capital of France?", options: ["London", "Paris", "Berlin"], correct: 1, explanation: "Paris is the capital and largest city of France." },
      { q: "Who painted the Mona Lisa?", options: ["Picasso", "Van Gogh", "Da Vinci"], correct: 2, explanation: "Leonardo da Vinci painted it in the early 16th century." },
      { q: "What is the currency of Japan?", options: ["Dollar", "Yuan", "Yen"], correct: 2, explanation: "The Japanese Yen (JPY) is the official currency." }
    ],
    'Daily Life': [
      { q: "How many hours are there in 2 days?", options: ["24", "48", "72"], correct: 1, explanation: "24 hours per day * 2 days = 48 hours." },
      { q: "Which vitamin do you get from Sunlight?", options: ["Vitamin A", "Vitamin C", "Vitamin D"], correct: 2, explanation: "Your skin produces Vitamin D when exposed to sunlight." },
      { q: "Which of these is healthy to drink?", options: ["Soda", "Water", "Energy Drink"], correct: 1, explanation: "Water is essential for health; others contain high sugar." },
      { q: "How often should you brush your teeth?", options: ["Once a week", "Once a day", "Twice a day"], correct: 2, explanation: "Dentists recommend brushing twice daily for oral health." },
      { q: "Which traffic light color means 'Stop'?", options: ["Green", "Yellow", "Red"], correct: 2, explanation: "Red signal requires all vehicles to stop." },
      { q: "What is the main ingredient in an Omelette?", options: ["Flour", "Eggs", "Milk"], correct: 1, explanation: "Omelettes are primarily made from beaten eggs." }
    ],
    Geography: [
      { q: "Which is the tallest mountain?", options: ["K2", "Everest", "Kilimanjaro"], correct: 1, explanation: "Mount Everest is 8,848 meters tall." },
      { q: "Which continent is known as the 'Dark Continent'?", options: ["Asia", "Africa", "Australia"], correct: 1, explanation: "Africa was once called this due to being largely unexplored by outsiders." },
      { q: "Which country is called the Land of Rising Sun?", options: ["China", "Japan", "Korea"], correct: 1, explanation: "Japan's name 'Nihon' literally means 'origin of the sun'." },
      { q: "What is the longest river in the world?", options: ["Amazon", "Nile", "Yangtze"], correct: 1, explanation: "The Nile is traditionally considered the longest, though Amazon is close." },
      { q: "Which is the smallest country?", options: ["Monaco", "Vatican City", "Maldives"], correct: 1, explanation: "Vatican City is an independent city-state of only 0.44 sq km." },
      { q: "Which desert is the largest hot desert?", options: ["Gobi", "Sahara", "Thar"], correct: 1, explanation: "The Sahara covers most of North Africa." }
    ],
    Sports: [
      { q: "Which country won the FIFA World Cup 2022?", options: ["France", "Argentina", "Brazil"], correct: 1, explanation: "Argentina defeated France in the final." },
      { q: "How many players are in a Cricket team?", options: ["9", "11", "13"], correct: 1, explanation: "A standard cricket team has 11 players." },
      { q: "Who is known as the King of Cricket?", options: ["Babar Azam", "Virat Kohli", "Sachin Tendulkar"], correct: 1, explanation: "Virat Kohli is often given this title by fans today." },
      { q: "Where were the first Olympics held?", options: ["Rome", "Athens", "Paris"], correct: 1, explanation: "The first modern games were in Athens, Greece (1896)." },
      { q: "Which sport is played at Wimbledon?", options: ["Golf", "Tennis", "Cricket"], correct: 1, explanation: "Wimbledon is the world's oldest and most prestigious tennis tournament." },
      { q: "What is the color of the ball in Snooker?", options: ["Orange", "Blue", "Many colors"], correct: 2, explanation: "Snooker uses 15 red balls and 6 other colors." }
    ],
    History: [
      { q: "When did Pakistan gain independence?", options: ["1945", "1947", "1950"], correct: 1, explanation: "Pakistan was created on 14th August 1947." },
      { q: "Who was the first President of USA?", options: ["Lincoln", "Jefferson", "Washington"], correct: 2, explanation: "George Washington served from 1789 to 1797." },
      { q: "The Great Wall is located in which country?", options: ["Japan", "China", "India"], correct: 1, explanation: "Built across the historical northern borders of China." },
      { q: "Which empire built the Taj Mahal?", options: ["Mughal", "British", "Ottoman"], correct: 0, explanation: "Emperor Shah Jahan built it for his wife Mumtaz." },
      { q: "World War II ended in which year?", options: ["1940", "1945", "1950"], correct: 1, explanation: "The war officially ended on September 2, 1945." },
      { q: "Who discovered America?", options: ["Columbus", "Magellan", "Vasco da Gama"], correct: 0, explanation: "Christopher Columbus reached the Americas in 1492." }
    ]
  };

  const currentQuestions = questionBank[subject];

  const handleAns = (idx: number) => {
    if (feedback?.show) return;
    
    const isCorrect = idx === currentQuestions[currentQ].correct;
    if (isCorrect) setScore(s => s + 1);
    
    setFeedback({ isCorrect, show: true });

    setTimeout(() => {
      setFeedback(null);
      if (currentQ < currentQuestions.length - 1) {
        setCurrentQ(currentQ + 1);
      } else {
        setStep('end');
      }
    }, 2500);
  };

  return (
    <div className="p-8 lg:p-12 max-w-4xl mx-auto h-full flex flex-col items-center justify-center space-y-8 animate-in fade-in duration-500">
      {step === 'start' && (
        <div className="text-center space-y-6">
          <div className="w-24 h-24 bg-brand-100 rounded-[2rem] flex items-center justify-center mx-auto text-brand-500 shadow-inner">
            <svg className="w-12 h-12" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2" /></svg>
          </div>
          <h2 className="text-4xl font-black text-slate-800 tracking-tighter">Mini Test Arena</h2>
          <p className="text-slate-500 font-medium">Quick sessions to test your knowledge across multiple subjects.</p>
          <button onClick={() => setStep('select')} className="bg-brand-600 text-white px-12 py-4 rounded-3xl font-black uppercase text-xs tracking-widest shadow-xl shadow-brand-200 hover:scale-105 transition-all">Start Daily Quiz</button>
        </div>
      )}

      {step === 'select' && (
        <div className="w-full text-center space-y-8 animate-in slide-in-from-bottom duration-500">
           <div className="space-y-2">
              <h3 className="text-2xl font-black text-slate-800">Select Category</h3>
              <p className="text-xs text-slate-400 font-bold uppercase tracking-widest">Choose a subject you want to master</p>
           </div>
           <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
              {(Object.keys(questionBank) as Subject[]).map(s => (
                <button key={s} onClick={() => { setSubject(s); setStep('playing'); setCurrentQ(0); setScore(0); }} className="glass-card p-8 rounded-[2.5rem] border-2 border-brand-50 hover:border-brand-500 transition-all font-black text-brand-600 uppercase text-[10px] tracking-widest flex flex-col items-center space-y-2">
                  <span className="text-2xl">
                    {s === 'IT' && '💻'}
                    {s === 'Science' && '🔬'}
                    {s === 'Math' && '📐'}
                    {s === 'Islam' && '🕌'}
                    {s === 'General' && '🌍'}
                    {s === 'Daily Life' && '🏠'}
                    {s === 'History' && '📜'}
                    {s === 'Geography' && '🏔️'}
                    {s === 'Sports' && '🏆'}
                  </span>
                  <span>{s}</span>
                </button>
              ))}
           </div>
        </div>
      )}

      {step === 'playing' && (
        <div className="w-full max-w-2xl glass-card rounded-[3rem] p-10 space-y-8 border-brand-200 shadow-2xl relative overflow-hidden">
          <div className="flex justify-between items-center text-[10px] font-black uppercase text-brand-400 tracking-[0.2em]">
            <span>{subject} Mode - Question {currentQ + 1} / {currentQuestions.length}</span>
            <span className="bg-brand-100 px-3 py-1 rounded-full">Score: {score}</span>
          </div>
          <h3 className="text-2xl font-black text-slate-800 leading-tight">{currentQuestions[currentQ].q}</h3>
          
          <div className="space-y-3">
            {currentQuestions[currentQ].options.map((opt, i) => {
              const isCorrect = i === currentQuestions[currentQ].correct;
              
              let btnClass = "w-full text-left p-6 rounded-2xl border-2 transition-all font-bold text-slate-600 ";
              if (feedback?.show) {
                if (isCorrect) btnClass += "bg-emerald-50 border-emerald-500 text-emerald-700 ";
                else if (feedback.show && !feedback.isCorrect && i !== currentQuestions[currentQ].correct) btnClass += "opacity-50 border-slate-100 ";
                else btnClass += "opacity-50 border-slate-100 ";
              } else {
                btnClass += "bg-white border-brand-50 hover:border-brand-400 hover:bg-brand-50/50 ";
              }

              return (
                <button key={i} onClick={() => handleAns(i)} className={btnClass}>
                  <div className="flex justify-between items-center">
                    <span>{opt}</span>
                    {feedback?.show && isCorrect && <span className="text-[10px] font-black uppercase tracking-widest bg-emerald-100 px-2 py-1 rounded">Correct Answer</span>}
                  </div>
                </button>
              );
            })}
          </div>

          {feedback?.show && (
            <div className={`p-6 rounded-2xl animate-in fade-in zoom-in duration-300 border ${feedback.isCorrect ? 'bg-emerald-50 text-emerald-700 border-emerald-200' : 'bg-red-50 text-red-700 border-red-200'}`}>
              <p className="text-[10px] font-black uppercase mb-1">{feedback.isCorrect ? '🌟 Correct!' : '❌ Let\'s Learn'}</p>
              <p className="text-sm font-medium">{currentQuestions[currentQ].explanation}</p>
            </div>
          )}
        </div>
      )}

      {step === 'end' && (
        <div className="text-center space-y-6">
          <div className="text-8xl mb-4 animate-bounce">🎖️</div>
          <h2 className="text-4xl font-black text-slate-800 tracking-tighter">Test Complete!</h2>
          <div className="bg-white p-8 rounded-[2.5rem] shadow-xl border border-brand-50">
            <p className="text-sm font-black text-slate-400 uppercase tracking-widest mb-1">Final Performance</p>
            <p className="text-5xl font-black text-brand-600">{score} / {currentQuestions.length}</p>
            <p className="text-xs text-slate-500 mt-4 font-bold uppercase">{score === currentQuestions.length ? "Perfect Score! You're a pro!" : "Good job! Keep practicing."}</p>
          </div>
          <div className="flex space-x-4 justify-center">
             <button onClick={() => {setStep('select'); setCurrentQ(0); setScore(0);}} className="bg-brand-600 text-white px-10 py-4 rounded-3xl font-black uppercase text-xs tracking-widest shadow-lg hover:scale-105 transition-all">Try Another</button>
             <button onClick={() => {setStep('start'); setCurrentQ(0); setScore(0);}} className="bg-slate-100 text-slate-400 px-10 py-4 rounded-3xl font-black uppercase text-xs tracking-widest hover:bg-slate-200 transition-all">Go Home</button>
          </div>
        </div>
      )}
    </div>
  );
};

export default MiniTest;
