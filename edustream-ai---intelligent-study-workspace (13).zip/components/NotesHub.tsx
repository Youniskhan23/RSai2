import React, { useState, useEffect } from 'react';
import { summarizeNotes } from '../services/geminiService';
import { NoteItem } from '../types';

const NotesHub: React.FC = () => {
  const [notes, setNotes] = useState<NoteItem[]>([]);
  const [isProcessing, setIsProcessing] = useState(false);
  const [newNoteText, setNewNoteText] = useState('');
  const [newNoteTitle, setNewNoteTitle] = useState('');
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    loadNotes();
  }, []);

  const loadNotes = () => {
    try {
      const saved = localStorage.getItem('study_notes');
      if (saved) {
        const parsed = JSON.parse(saved);
        setNotes(parsed.filter((n: NoteItem) => !n.isArchived));
      }
    } catch (e) {
      console.error("Error loading notes", e);
    }
  };

  const saveNotesToStorage = (updated: NoteItem[]) => {
    try {
      localStorage.setItem('study_notes', JSON.stringify(updated));
      setNotes(updated.filter(n => !n.isArchived));
    } catch (e) {
      console.error("Error saving notes", e);
      setError("Storage is full or inaccessible. Try deleting old notes.");
    }
  };

  const handleProcess = async () => {
    if (!newNoteText.trim()) {
      setError("Please paste some text first.");
      return;
    }
    setError(null);
    setIsProcessing(true);
    
    try {
      // Attempt AI summarization
      let finalContent = newNoteText;
      try {
        const summary = await summarizeNotes(newNoteText);
        if (summary) finalContent = summary;
      } catch (aiErr) {
        console.warn("AI summary failed, falling back to original text.", aiErr);
      }

      const newNote: NoteItem = {
        id: Date.now().toString(),
        title: newNoteTitle.trim() || `Study Note - ${new Date().toLocaleDateString()}`,
        content: finalContent,
        timestamp: new Date().toISOString().split('T')[0],
        tags: ['Academic'],
        isArchived: false
      };

      const existingData = localStorage.getItem('study_notes');
      const allNotes = existingData ? JSON.parse(existingData) : [];
      saveNotesToStorage([newNote, ...allNotes]);
      
      setNewNoteText('');
      setNewNoteTitle('');
    } catch (err) {
      console.error("Notes process error:", err);
      setError("Failed to add note. Please try again.");
    } finally {
      setIsProcessing(false);
    }
  };

  const archiveNote = (id: string) => {
    try {
      const existingData = localStorage.getItem('study_notes');
      const allNotes = existingData ? JSON.parse(existingData) : [];
      const updated = allNotes.map((n: NoteItem) => n.id === id ? { ...n, isArchived: true } : n);
      saveNotesToStorage(updated);
    } catch (e) {
      console.error("Archive failed", e);
    }
  };

  return (
    <div className="p-4 lg:p-12 grid grid-cols-1 lg:grid-cols-3 gap-8 max-w-7xl mx-auto h-full animate-in fade-in duration-500">
      <div className="lg:col-span-1 space-y-6">
        <div className="glass-card rounded-[2.5rem] p-8 shadow-xl border border-brand-100">
          <h3 className="text-xl font-black mb-6 text-slate-800 dark:text-slate-100 uppercase tracking-tight">Add Material</h3>
          <div className="space-y-4">
            <input 
              type="text" 
              className="w-full bg-slate-50 dark:bg-slate-800 border-2 border-transparent focus:border-brand-500 rounded-2xl p-4 text-sm dark:text-slate-100 outline-none transition-all shadow-inner" 
              placeholder="Topic Title (Optional)" 
              value={newNoteTitle} 
              onChange={(e) => setNewNoteTitle(e.target.value)} 
            />
            <textarea 
              className="w-full h-64 bg-slate-50 dark:bg-slate-800 border-2 border-transparent focus:border-brand-500 rounded-[2rem] p-6 text-sm dark:text-slate-100 resize-none outline-none transition-all shadow-inner" 
              placeholder="Paste text here..." 
              value={newNoteText} 
              onChange={(e) => setNewNoteText(e.target.value)} 
            />
            {error && <p className="text-[10px] font-bold text-red-500 uppercase px-2">{error}</p>}
            <button 
              onClick={handleProcess} 
              disabled={isProcessing || !newNoteText.trim()} 
              className="w-full bg-brand-600 hover:bg-brand-700 text-white py-4 rounded-2xl font-black uppercase text-xs tracking-widest shadow-xl shadow-brand-100 disabled:opacity-50 transition-all active:scale-95"
            >
              {isProcessing ? 'Saving Note...' : 'Add Study Note ✨'}
            </button>
          </div>
        </div>
      </div>

      <div className="lg:col-span-2 space-y-6 overflow-y-auto max-h-[calc(100vh-160px)] hide-scrollbar pr-2">
        {notes.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-32 opacity-20">
            <svg className="w-20 h-20 mb-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="1" d="M19 11H5m14 0a2 2 0 012 2v6a2 2 0 01-2 2H5a2 2 0 01-2-2v-6a2 2 0 012-2m14 0V9a2 2 0 00-2-2M5 11V9a2 2 0 012-2m0 0V5a2 2 0 012-2h6a2 2 0 012 2v2M7 7h10" /></svg>
            <p className="font-bold uppercase tracking-widest text-xs">Knowledge Base Empty</p>
          </div>
        ) : (
          notes.map(note => (
            <div key={note.id} className="glass-card rounded-[2.5rem] p-8 shadow-lg border border-brand-50 group hover:ring-2 hover:ring-brand-100 transition-all animate-in slide-in-from-right duration-500">
              <div className="flex justify-between items-start mb-6">
                <div>
                  <h4 className="text-xl font-black text-slate-800 dark:text-white tracking-tight">{note.title}</h4>
                  <div className="flex items-center space-x-2 mt-1">
                    <span className="text-[10px] text-brand-400 font-bold uppercase tracking-widest">{note.timestamp}</span>
                    <span className="w-1 h-1 bg-slate-200 rounded-full"></span>
                    <span className="text-[10px] text-slate-400 font-bold uppercase tracking-widest">{note.tags[0]}</span>
                  </div>
                </div>
                <button 
                  onClick={() => archiveNote(note.id)} 
                  className="p-2 text-slate-300 hover:text-brand-500 transition-colors"
                  title="Archive Note"
                >
                  <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 8h14M5 8a2 2 0 110-4h14a2 2 0 110 4M5 8v10a2 2 0 002 2h10a2 2 0 002-2V8m-9 4h4" /></svg>
                </button>
              </div>
              <div className="text-sm text-slate-600 dark:text-slate-400 leading-relaxed whitespace-pre-wrap font-medium">{note.content}</div>
            </div>
          ))
        )}
      </div>
    </div>
  );
};

export default NotesHub;