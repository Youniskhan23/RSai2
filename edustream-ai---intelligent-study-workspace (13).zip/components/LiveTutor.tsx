import React, { useState, useEffect, useRef } from 'react';
import { GoogleGenAI, LiveServerMessage, Modality, Blob } from '@google/genai';
import { encode, decode, decodeAudioData } from '../services/geminiService';
import { Language } from '../types';

const LiveTutor: React.FC = () => {
  const [isActive, setIsActive] = useState(false);
  const [isConnecting, setIsConnecting] = useState(false);
  const [transcriptions, setTranscriptions] = useState<{role: 'user'|'model', text: string}[]>([]);
  const [currentTranscription, setCurrentTranscription] = useState('');
  const [selectedLanguage, setSelectedLanguage] = useState<Language>('english');
  
  const audioContextRef = useRef<AudioContext | null>(null);
  const outputAudioContextRef = useRef<AudioContext | null>(null);
  const nextStartTimeRef = useRef(0);
  const sourcesRef = useRef<Set<AudioBufferSourceNode>>(new Set());
  const sessionRef = useRef<any>(null);

  const stopSession = () => {
    if (sessionRef.current) {
      try { sessionRef.current.close(); } catch(e) {}
    }
    setIsActive(false);
    setIsConnecting(false);
    // Standard cleanup to release mic
    if (audioContextRef.current) {
      audioContextRef.current.close();
      audioContextRef.current = null;
    }
  };

  const startSession = async () => {
    setIsConnecting(true);
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || '' });

    const langInstructions = {
      'english': 'respond ONLY in English.',
      'urdu': 'respond ONLY in Urdu (spoken).',
      'roman-english': 'respond ONLY in Roman English (Urdu/Hinglish phrasing written out in transcriptions).'
    };

    try {
      const audioCtx = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 16000 });
      const outCtx = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 24000 });
      audioContextRef.current = audioCtx;
      outputAudioContextRef.current = outCtx;

      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      
      const sessionPromise = ai.live.connect({
        model: 'gemini-2.5-flash-native-audio-preview-12-2025',
        callbacks: {
          onopen: () => {
            setIsActive(true);
            setIsConnecting(false);

            const source = audioCtx.createMediaStreamSource(stream);
            const scriptProcessor = audioCtx.createScriptProcessor(4096, 1, 1);
            
            scriptProcessor.onaudioprocess = (e) => {
              const inputData = e.inputBuffer.getChannelData(0);
              const int16 = new Int16Array(inputData.length);
              for (let i = 0; i < inputData.length; i++) {
                int16[i] = inputData[i] * 32768;
              }
              
              const pcmBlob: Blob = {
                data: encode(new Uint8Array(int16.buffer, int16.byteOffset, int16.byteLength)),
                mimeType: 'audio/pcm;rate=16000',
              };
              
              sessionPromise.then(session => {
                session.sendRealtimeInput({ media: pcmBlob });
              });
            };

            source.connect(scriptProcessor);
            scriptProcessor.connect(audioCtx.destination);
          },
          onmessage: async (message: LiveServerMessage) => {
            if (message.serverContent?.outputTranscription) {
              setCurrentTranscription(prev => prev + message.serverContent?.outputTranscription?.text);
            }
            if (message.serverContent?.turnComplete) {
              setCurrentTranscription(text => {
                if (text) setTranscriptions(prev => [...prev, {role: 'model', text}]);
                return '';
              });
            }

            const base64Audio = message.serverContent?.modelTurn?.parts[0]?.inlineData?.data;
            if (base64Audio && outputAudioContextRef.current) {
              const ctx = outputAudioContextRef.current;
              nextStartTimeRef.current = Math.max(nextStartTimeRef.current, ctx.currentTime);
              
              const audioBuffer = await decodeAudioData(decode(base64Audio), ctx, 24000, 1);
              const source = ctx.createBufferSource();
              source.buffer = audioBuffer;
              source.connect(ctx.destination);
              source.addEventListener('ended', () => sourcesRef.current.delete(source));
              source.start(nextStartTimeRef.current);
              nextStartTimeRef.current += audioBuffer.duration;
              sourcesRef.current.add(source);
            }

            if (message.serverContent?.interrupted) {
              sourcesRef.current.forEach(s => { try { s.stop(); } catch(e) {} });
              sourcesRef.current.clear();
              nextStartTimeRef.current = 0;
            }
          },
          onerror: (e) => {
            console.error("Live Tutor Error:", e);
            stopSession();
          },
          onclose: () => {
            stopSession();
          }
        },
        config: {
          responseModalities: [Modality.AUDIO],
          outputAudioTranscription: {},
          inputAudioTranscription: {},
          speechConfig: { voiceConfig: { prebuiltVoiceConfig: { voiceName: 'Zephyr' } } },
          systemInstruction: `You are EduStream AI, a friendly and brilliant study tutor. You help students understand complex IT concepts simply. You MUST ${langInstructions[selectedLanguage]}`
        }
      });

      sessionRef.current = await sessionPromise;
    } catch (err) {
      console.error(err);
      setIsConnecting(false);
      alert("Microphone access failed. Please ensure you have given permission.");
    }
  };

  return (
    <div className="p-8 h-full flex flex-col space-y-6 max-w-4xl mx-auto">
      <div className="text-center space-y-2">
        <h2 className="text-2xl font-black text-slate-800 tracking-tighter">Professor AI Live</h2>
        <p className="text-slate-400 text-xs font-bold uppercase tracking-widest">Real-time Spoken Tutoring</p>
      </div>

      <div className="flex-1 glass-card rounded-[3rem] p-10 relative overflow-hidden flex flex-col items-center justify-center border-brand-100 shadow-sm min-h-[400px]">
        {!isActive && !isConnecting ? (
          <div className="text-center space-y-6 animate-in fade-in duration-500">
            <div className="w-24 h-24 bg-brand-50 rounded-full flex items-center justify-center mx-auto shadow-inner">
              <svg className="w-10 h-10 text-brand-300" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 11a7 7 0 01-7 7m0 0a7 7 0 01-7-7m7 7v4m0 0H8m4 0h4m-4-8a3 3 0 01-3-3V5a3 3 0 116 0v6a3 3 0 01-3 3z" />
              </svg>
            </div>
            <div className="space-y-4">
              <div className="flex bg-slate-50 p-1 rounded-2xl border border-slate-100 w-fit mx-auto">
                {(['english', 'urdu', 'roman-english'] as Language[]).map((lang) => (
                  <button key={lang} onClick={() => setSelectedLanguage(lang)} className={`px-4 py-2 rounded-xl text-[9px] font-black uppercase tracking-widest transition-all ${selectedLanguage === lang ? 'bg-brand-50 text-brand-500' : 'text-slate-300'}`}>
                    {lang.split('-').join(' ')}
                  </button>
                ))}
              </div>
              <button onClick={startSession} className="bg-brand-50 hover:bg-brand-100 text-brand-500 px-10 py-4 rounded-2xl font-black uppercase text-xs tracking-widest shadow-sm transition-all active:scale-95">
                Connect Voice Link
              </button>
            </div>
          </div>
        ) : isConnecting ? (
          <div className="text-center space-y-4">
             <div className="w-10 h-10 border-4 border-brand-200 border-t-transparent rounded-full animate-spin mx-auto"></div>
             <p className="text-brand-300 text-[10px] font-black uppercase tracking-widest animate-pulse">Establishing Signal...</p>
          </div>
        ) : (
          <div className="w-full h-full flex flex-col animate-in fade-in duration-300">
            <div className="flex-1 overflow-y-auto space-y-4 p-4 hide-scrollbar">
               {transcriptions.length === 0 && !currentTranscription && <p className="text-center text-slate-300 italic text-sm mt-20">Start speaking to your AI Professor...</p>}
               {transcriptions.map((t, i) => (
                 <div key={i} className={`flex ${t.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                    <div className={`max-w-[85%] rounded-[2rem] px-5 py-3 text-sm font-medium ${t.role === 'user' ? 'bg-brand-100/60 text-brand-600' : 'bg-slate-50 text-slate-600'}`}>
                      {t.text}
                    </div>
                 </div>
               ))}
               {currentTranscription && (
                 <div className="flex justify-start">
                    <div className="max-w-[85%] rounded-[2rem] px-5 py-3 bg-slate-50 text-slate-400 italic text-sm animate-pulse">
                      {currentTranscription}...
                    </div>
                 </div>
               )}
            </div>

            <div className="h-24 flex items-center justify-center space-x-8 mt-4">
              <button onClick={stopSession} className="w-16 h-16 bg-red-50/50 hover:bg-red-100 text-red-400 rounded-full flex items-center justify-center transition-all active:scale-90 shadow-sm">
                <svg className="w-6 h-6" fill="currentColor" viewBox="0 0 20 20"><path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM8 7a1 1 0 00-1 1v4a1 1 0 001 1h4a1 1 0 001-1V8a1 1 0 00-1-1H8z" clipRule="evenodd" /></svg>
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default LiveTutor;