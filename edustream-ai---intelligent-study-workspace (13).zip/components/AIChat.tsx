import React, { useState, useRef, useEffect } from 'react';
import { getAIChatResponse } from '../services/geminiService';
import { Language, ChatHistoryItem } from '../types';

interface ChatMessage { role: 'user' | 'model'; text: string; attachments?: string[]; }

const AIChat: React.FC = () => {
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [inputText, setInputText] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const [attachments, setAttachments] = useState<{mimeType: string, data: string, preview: string}[]>([]);
  const [isListening, setIsListening] = useState(false);
  const [selectedLanguage, setSelectedLanguage] = useState<Language>('english');
  const messagesEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, isTyping]);

  const handleSendMessage = async () => {
    if (!inputText.trim() && attachments.length === 0) return;
    const prompt = inputText;
    const atts = [...attachments];
    const apiAtts = atts.map(a => ({ mimeType: a.mimeType, data: a.data }));
    setMessages(prev => [...prev, { role: 'user', text: prompt, attachments: atts.map(a => a.preview) }]);
    setInputText(''); setAttachments([]); setIsTyping(true);
    try {
      const history = messages.map(m => ({ role: m.role, parts: [{ text: m.text }] }));
      const response = await getAIChatResponse(prompt, history, apiAtts, selectedLanguage);
      setMessages(prev => [...prev, { role: 'model', text: response }]);
    } catch (err) { setMessages(prev => [...prev, { role: 'model', text: "Error. Try again." }]); } finally { setIsTyping(false); }
  };

  const startVoice = () => {
    const sr = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (!sr) {
      alert("Voice recognition is not supported in this browser.");
      return;
    }
    const rec = new sr();
    rec.lang = selectedLanguage === 'urdu' ? 'ur-PK' : 'en-US';
    rec.onstart = () => setIsListening(true);
    rec.onend = () => setIsListening(false);
    rec.onresult = (e: any) => {
      const transcript = e.results[0][0].transcript;
      setInputText(prev => prev + (prev ? ' ' : '') + transcript);
    };
    rec.start();
  };

  const handleFile = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(e.target.files || []);
    files.forEach(f => {
      const r = new FileReader();
      r.onload = () => setAttachments(p => [...p, { mimeType: f.type, data: (r.result as string).split(',')[1], preview: r.result as string }]);
      r.readAsDataURL(f);
    });
  };

  return (
    <div className="flex flex-col h-full max-w-5xl mx-auto p-6 lg:p-10 space-y-6">
      <header className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-black text-slate-800 dark:text-white">EduStream Chat</h2>
          <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mt-1">Multi-Modal Study Assistant</p>
        </div>
        <div className="flex bg-white dark:bg-slate-900 p-1 rounded-2xl shadow-sm border border-slate-100 dark:border-slate-800">
          {(['english', 'urdu', 'roman-english'] as Language[]).map(l => (
            <button key={l} onClick={() => setSelectedLanguage(l)} className={`px-4 py-1.5 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all ${selectedLanguage === l ? 'bg-brand-500 text-slate-900 shadow-sm' : 'text-slate-300 hover:text-brand-200'}`}>
              {l.replace('-english', '')}
            </button>
          ))}
        </div>
      </header>

      <div className="flex-1 glass-card rounded-[2.5rem] overflow-hidden flex flex-col relative border-white/50 dark:border-slate-800">
        <div className="flex-1 overflow-y-auto p-8 space-y-8 hide-scrollbar">
          {messages.length === 0 && (
            <div className="h-full flex flex-col items-center justify-center text-center opacity-30">
              <div className="w-16 h-16 bg-brand-50/50 dark:bg-slate-900 rounded-2xl flex items-center justify-center mb-6 text-brand-200">
                <svg className="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M8 10h.01M12 10h.01M16 10h.01M9 16H5a2 2 0 01-2-2V6a2 2 0 012-2h14a2 2 0 012 2v8a2 2 0 01-2 2h-5l-5 5v-5z" /></svg>
              </div>
              <p className="text-[10px] font-black uppercase tracking-[0.2em] text-brand-300">Intelligent Academic Collaboration</p>
            </div>
          )}
          {messages.map((m, i) => (
            <div key={i} className={`flex ${m.role === 'user' ? 'justify-end' : 'justify-start'} animate-in slide-in-from-bottom-2 duration-300`}>
              <div className={`max-w-[85%] rounded-[2rem] p-6 shadow-sm ${m.role === 'user' ? 'bg-brand-50 text-brand-700 rounded-tr-none' : 'bg-white/80 dark:bg-slate-900 text-slate-600 dark:text-slate-200 border border-white dark:border-slate-800 rounded-tl-none'}`}>
                {m.attachments?.map((a, idx) => <img key={idx} src={a} className="w-32 h-32 object-cover rounded-xl mb-3 shadow-md border-2 border-white/20" alt="Att" />)}
                <div className={`text-sm lg:text-base whitespace-pre-wrap leading-relaxed ${selectedLanguage === 'urdu' ? 'urdu-text' : 'font-medium'}`}>{m.text}</div>
              </div>
            </div>
          ))}
          {isTyping && <div className="flex justify-start px-6"><div className="w-1.5 h-1.5 bg-brand-200 rounded-full animate-bounce"></div></div>}
          <div ref={messagesEndRef} />
        </div>

        {isListening && <div className="absolute inset-0 bg-brand-50/20 backdrop-blur-sm flex items-center justify-center z-20 font-black text-brand-500 uppercase tracking-widest animate-pulse">Listening...</div>}

        <div className="p-6 bg-white/40 dark:bg-slate-950/80 backdrop-blur-md border-t border-slate-50 dark:border-slate-800">
          <div className="flex items-center space-x-2 bg-white/60 dark:bg-slate-900/50 p-2 rounded-[2rem] border border-brand-50 dark:border-slate-800 focus-within:ring-4 focus-within:ring-brand-50/30 transition-all shadow-sm">
            <input type="file" multiple id="chat-f" className="hidden" onChange={handleFile} />
            <label htmlFor="chat-f" className="p-3 text-slate-400 hover:text-brand-400 cursor-pointer transition-colors"><svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M15.172 7l-6.586 6.586a2 2 0 102.828 2.828l6.414-6.586a4 4 0 00-5.656-5.656l-6.415 6.585a6 6 0 108.486 8.486L20.5 13" /></svg></label>
            
            <button onClick={startVoice} className={`p-3 transition-colors ${isListening ? 'text-red-500 animate-pulse' : 'text-slate-400 hover:text-brand-400'}`}>
              <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M19 11a7 7 0 01-7 7m0 0a7 7 0 01-7-7m7 7v4m0 0H8m4 0h4m-4-8a3 3 0 01-3-3V5a3 3 0 116 0v6a3 3 0 01-3 3z" /></svg>
            </button>

            <textarea 
              className="flex-1 bg-transparent border-none outline-none text-sm dark:text-white placeholder-slate-300 resize-none max-h-32 px-2 py-3 font-semibold text-slate-700" 
              placeholder="Type or speak..." 
              rows={1} 
              value={inputText} 
              onChange={e=>setInputText(e.target.value)} 
              onKeyDown={e => { if(e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); handleSendMessage(); } }}
            />
            
            <button onClick={handleSendMessage} className="bg-brand-500 text-white p-3 rounded-2xl shadow-sm active:scale-90 transition-all">
              <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="3" d="M12 19l9 2-9-18-9 18 9-2zm0 0v-8" /></svg>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AIChat;