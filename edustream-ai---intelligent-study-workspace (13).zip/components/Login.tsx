import React, { useState } from 'react';

interface LoginProps {
  onLogin: (email: string) => void;
}

const Login: React.FC<LoginProps> = ({ onLogin }) => {
  const [email, setEmail] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (email.includes('@')) {
      localStorage.setItem('user_email', email);
      onLogin(email);
    }
  };

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center bg-[#fefeff] dark:bg-slate-950 p-6">
      <div className="absolute inset-0 overflow-hidden opacity-5 dark:opacity-10 pointer-events-none">
        <div className="absolute top-[-10%] left-[-10%] w-[60%] h-[60%] bg-brand-200 rounded-full blur-[180px]"></div>
        <div className="absolute bottom-[-10%] right-[-10%] w-[60%] h-[60%] bg-brand-100 rounded-full blur-[180px]"></div>
      </div>
      
      <div className="glass-card w-full max-w-md p-10 rounded-[3.5rem] text-center space-y-8 animate-in zoom-in duration-700 relative z-10 border-brand-50">
        <div className="space-y-2">
          <h1 className="text-4xl font-black gradient-text tracking-tighter">EduStream AI</h1>
          <p className="text-[10px] font-black text-brand-300 uppercase tracking-[0.3em]">LEARNING WORKSPACE</p>
        </div>
        
        <div className="space-y-4">
          <h2 className="text-xl font-bold text-slate-700 dark:text-white">Welcome Back!</h2>
          <p className="text-sm text-slate-400 dark:text-slate-400 leading-relaxed px-4">Ready to start your session? Just enter your email to continue.</p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-5">
          <input 
            type="email" 
            required
            className="w-full bg-white dark:bg-slate-900 border border-brand-100 dark:border-slate-800 rounded-2xl p-5 text-center font-bold outline-none transition-all dark:text-white text-slate-600 placeholder:text-slate-200 shadow-sm focus:border-brand-300"
            placeholder="name@email.com"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
          />
          <button 
            type="submit"
            className="w-full bg-brand-500 hover:bg-brand-600 text-white py-5 rounded-2xl font-black text-xs uppercase tracking-widest shadow-xl shadow-brand-100 transition-all active:scale-95"
          >
            Access Workspace
          </button>
        </form>
        
        <p className="text-[9px] text-slate-300 font-black uppercase tracking-[0.4em]">Final Year IT Module</p>
      </div>
    </div>
  );
};

export default Login;