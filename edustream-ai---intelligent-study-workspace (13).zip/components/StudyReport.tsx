import React, { useEffect, useState } from 'react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Cell, PieChart, Pie } from 'recharts';
import { getAIChatResponse } from '../services/geminiService';

const StudyReport: React.FC = () => {
  const [stats, setStats] = useState({ notes: 0, chats: 0, facts: 0, testScore: 0 });
  const [advice, setAdvice] = useState('');
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    const n = JSON.parse(localStorage.getItem('study_notes') || '[]').length;
    const c = JSON.parse(localStorage.getItem('chat_history') || '[]').length;
    const f = JSON.parse(localStorage.getItem('fact_history') || '[]').length;
    setStats({ notes: n, chats: c, facts: f, testScore: 88 }); // Mocked score
    generateAdvice(n, c, f);
  }, []);

  const generateAdvice = async (n: number, c: number, f: number) => {
    setLoading(true);
    try {
      const msg = `User stats: ${n} notes, ${c} chats, ${f} fact checks. Give 2 short, bold academic advice steps for them.`;
      const res = await getAIChatResponse(msg, [], []);
      setAdvice(res);
    } catch (e) {
      setAdvice("Keep pushing your boundaries. Consistency is key!");
    } finally {
      setLoading(false);
    }
  };

  const chartData = [
    { name: 'Notes', val: stats.notes, color: '#c1b5ff' },
    { name: 'Chats', val: stats.chats, color: '#e9e4ff' },
    { name: 'Facts', val: stats.facts, color: '#dfd9ff' }
  ];

  return (
    <div className="p-6 lg:p-12 max-w-6xl mx-auto space-y-10 animate-in fade-in duration-700">
      <header className="space-y-1">
        <h2 className="text-3xl font-black text-slate-950 dark:text-white tracking-tighter uppercase">Performance Report</h2>
        <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Real-time learning metrics</p>
      </header>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
        <div className="glass-card rounded-[3rem] p-10 col-span-2 space-y-8 border-brand-100 shadow-xl">
           <h3 className="text-sm font-black text-slate-800 dark:text-white uppercase tracking-widest">Activity Distribution</h3>
           <div className="h-[300px] w-full">
              <ResponsiveContainer width="100%" height="100%">
                 <BarChart data={chartData}>
                    <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f4f1ff" className="dark:opacity-5" />
                    <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{fill: '#c1b5ff', fontSize: 10, fontWeight: 900}} />
                    <Tooltip cursor={{fill: 'transparent'}} contentStyle={{ borderRadius: '20px', border: 'none', boxShadow: '0 10px 30px rgba(0,0,0,0.05)' }} />
                    <Bar dataKey="val" radius={[12, 12, 12, 12]} barSize={60}>
                       {chartData.map((entry, index) => <Cell key={`cell-${index}`} fill={entry.color} />)}
                    </Bar>
                 </BarChart>
              </ResponsiveContainer>
           </div>
        </div>

        <div className="space-y-8">
           <div className="glass-card rounded-[3rem] p-10 flex flex-col items-center text-center space-y-4 border-brand-100 shadow-xl bg-brand-50/20">
              <span className="text-[10px] font-black text-brand-500 uppercase tracking-widest">Mastery Level</span>
              <div className="text-6xl font-black text-slate-900 dark:text-white">{stats.testScore}%</div>
              <p className="text-[10px] text-slate-400 font-bold uppercase tracking-widest">Academic Excellence Tier</p>
           </div>

           <div className="bg-brand-500 rounded-[3rem] p-10 text-slate-900 shadow-2xl shadow-brand-100 space-y-4 animate-in slide-in-from-right duration-500">
              <h4 className="text-[10px] font-black uppercase tracking-[0.2em] opacity-70">AI Recommendation</h4>
              <p className="text-sm font-black italic leading-snug">
                {loading ? "Calculating insights..." : advice}
              </p>
           </div>
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
        {[
          { label: 'Total Notes', val: stats.notes, unit: 'Items', icon: '📝' },
          { label: 'AI Interactions', val: stats.chats, unit: 'Sessions', icon: '💬' },
          { label: 'Statements Verified', val: stats.facts, unit: 'Checks', icon: '✅' },
          { label: 'Active Days', val: 12, unit: 'Streak', icon: '🔥' },
        ].map((item, i) => (
          <div key={i} className="glass-card p-8 rounded-[2.5rem] flex flex-col items-center space-y-2 border-brand-50">
            <span className="text-2xl mb-2">{item.icon}</span>
            <span className="text-2xl font-black text-slate-900 dark:text-white">{item.val}</span>
            <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest">{item.label}</span>
          </div>
        ))}
      </div>
    </div>
  );
};

export default StudyReport;