import React, { useState, useEffect } from 'react';
import Sidebar from './components/Sidebar';
import Dashboard from './components/Dashboard';
import LiveTutor from './components/LiveTutor';
import NotesHub from './components/NotesHub';
import AIChat from './components/AIChat';
import FactChecker from './components/FactChecker';
import HistoryView from './components/HistoryView';
import ArchiveView from './components/ArchiveView';
import GamesRoom from './components/GamesRoom';
import KidsStartup from './components/KidsStartup';
import MiniTest from './components/MiniTest';
import SmartQuiz from './components/SmartQuiz';
import Login from './components/Login';
import AnalysisVault from './components/AnalysisVault';
import StudyReport from './components/StudyReport';
import { AppTab } from './types';

const PlaceholderView: React.FC<{ title: string; subtitle: string }> = ({ title, subtitle }) => (
  <div className="flex flex-col items-center justify-center h-full p-8 text-center space-y-4">
    <div className="w-20 h-20 bg-brand-50 rounded-[2rem] flex items-center justify-center text-brand-300 mb-4 shadow-inner animate-pulse">
      <svg className="w-10 h-10" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19.428 15.428a2 2 0 00-1.022-.547l-2.387-.477a6 6 0 00-3.86.517l-.318.158a6 6 0 01-3.86.517L6.05 15.21a2 2 0 00-1.183.244l-.28.14a2 2 0 00-1.012 2.05L4.5 21h15l.925-3.438a2 2 0 00-1.012-2.05l-.28-.14a2 2 0 00-1.183-.244l-2.531.506zM12 13V4M12 4L9 7m3-3l3 3" /></svg>
    </div>
    <h2 className="text-2xl font-black text-slate-800 tracking-tighter uppercase">{title}</h2>
    <p className="text-xs font-bold text-slate-400 uppercase tracking-widest">{subtitle}</p>
    <button onClick={() => window.location.reload()} className="px-6 py-2 bg-brand-50 text-brand-500 rounded-xl font-bold shadow-sm hover:bg-brand-100 transition-all text-[10px] uppercase tracking-widest mt-4">Refresh Hub</button>
  </div>
);

const App: React.FC = () => {
  const [userEmail, setUserEmail] = useState<string | null>(localStorage.getItem('user_email'));
  const [activeTab, setActiveTab] = useState<AppTab>(AppTab.DASHBOARD);
  const [fontSize, setFontSize] = useState(16);
  const [isDarkMode, setIsDarkMode] = useState(() => {
    return localStorage.getItem('theme') === 'dark' || 
           (!localStorage.getItem('theme') && window.matchMedia('(prefers-color-scheme: dark)').matches);
  });

  useEffect(() => {
    document.documentElement.style.setProperty('--app-font-size', `${fontSize}px`);
  }, [fontSize]);

  useEffect(() => {
    if (isDarkMode) {
      document.documentElement.classList.add('dark');
      localStorage.setItem('theme', 'dark');
    } else {
      document.documentElement.classList.remove('dark');
      localStorage.setItem('theme', 'light');
    }
  }, [isDarkMode]);

  const adjustFontSize = (delta: number) => {
    setFontSize(prev => Math.min(Math.max(prev + delta, 12), 24));
  };

  const renderContent = () => {
    switch (activeTab) {
      case AppTab.DASHBOARD: return <Dashboard onNavigate={setActiveTab} />;
      case AppTab.LIVE_TUTOR: return <LiveTutor />;
      case AppTab.STUDY_NOTES: return <NotesHub />;
      case AppTab.CHAT: return <AIChat />;
      case AppTab.FACT_CHECKER: return <FactChecker />;
      case AppTab.HISTORY: return <HistoryView />;
      case AppTab.ARCHIVE: return <ArchiveView />;
      case AppTab.REFRESHMENT: return <GamesRoom />;
      case AppTab.KIDS_STARTUP: return <KidsStartup />;
      case AppTab.MINI_TEST: return <MiniTest />;
      case AppTab.SMART_QUIZ: return <SmartQuiz />;
      case AppTab.ANALYSIS_VAULT: return <AnalysisVault />;
      case AppTab.STUDY_REPORT: return <StudyReport />;
      default: return <Dashboard onNavigate={setActiveTab} />;
    }
  };

  if (!userEmail) {
    return <Login onLogin={setUserEmail} />;
  }

  return (
    <div className="min-h-screen flex flex-col lg:flex-row transition-colors duration-300">
      <Sidebar 
        activeTab={activeTab} 
        setActiveTab={setActiveTab} 
        isDarkMode={isDarkMode} 
        toggleDarkMode={() => setIsDarkMode(!isDarkMode)}
        onAdjustFontSize={adjustFontSize}
        fontSize={fontSize}
      />
      
      <main className="flex-1 lg:ml-72 overflow-auto h-screen bg-[#fefeff] dark:bg-slate-950">
        <div className="max-w-[1400px] mx-auto min-h-full">
          {renderContent()}
        </div>
      </main>
    </div>
  );
};

export default App;