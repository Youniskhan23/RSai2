
export interface StudySession {
  id: string;
  topic: string;
  date: string;
  duration: number;
  masteryScore: number;
}

export interface NoteItem {
  id: string;
  title: string;
  content: string;
  timestamp: string;
  tags: string[];
  isArchived?: boolean;
}

export interface ChatHistoryItem {
  id: string;
  preview: string;
  timestamp: string;
  language: string;
}

export interface FactCheckHistoryItem {
  id: string;
  statement: string;
  score: number;
  verdict: string;
  timestamp: string;
  isArchived?: boolean;
}

export type Language = 'english' | 'urdu' | 'roman-english';

export enum AppTab {
  DASHBOARD = 'dashboard',
  STUDY_NOTES = 'study-notes',
  SMART_QUIZ = 'smart-quiz',
  LIVE_TUTOR = 'live-tutor',
  MINI_TEST = 'mini-test',
  KIDS_STARTUP = 'kids-startup',
  CHAT = 'chat',
  FACT_CHECKER = 'fact-checker',
  ANALYSIS_VAULT = 'analysis-vault',
  HISTORY = 'history',
  ARCHIVE = 'archive',
  STUDY_REPORT = 'study-report',
  REFRESHMENT = 'refreshment'
}
