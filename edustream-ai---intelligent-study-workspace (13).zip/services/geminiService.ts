
import { GoogleGenAI, Type, GenerateContentResponse, Modality, Blob, LiveServerMessage } from "@google/genai";
import { Language } from "../types";

// Standard client for text/image tasks
const getAIClient = () => new GoogleGenAI({ apiKey: process.env.API_KEY || '' });

export const getAIChatResponse = async (
  prompt: string, 
  history: {role: 'user'|'model', parts: any[]}[],
  attachments: {mimeType: string, data: string}[],
  language: Language = 'english'
): Promise<string> => {
  const ai = getAIClient();
  
  const currentParts: any[] = [{ text: prompt }];
  attachments.forEach(att => {
    currentParts.push({
      inlineData: att
    });
  });

  const langInstructions = {
    'english': 'respond ONLY in English.',
    'urdu': 'respond ONLY in Urdu (using Urdu script).',
    'roman-english': 'respond ONLY in Roman English (Urdu/Hinglish written in Latin characters).'
  };

  const response = await ai.models.generateContent({
    model: 'gemini-3-flash-preview',
    contents: [
      ...history.map(h => ({ role: h.role === 'user' ? 'user' : 'model', parts: h.parts })),
      { role: 'user', parts: currentParts }
    ],
    config: {
      systemInstruction: `You are EduStream AI Chat (like GPT). You MUST ${langInstructions[language]} You are helpful, intelligent, and can analyze images, text files, and voice queries. Always be polite and academic yet accessible.`
    }
  });

  return response.text || "I couldn't process that request.";
};

export const factCheckStatement = async (statement: string, language: Language = 'english'): Promise<{score: number, verdict: string, explanation: string}> => {
  const ai = getAIClient();
  const langInstructions = {
    'english': 'Respond in English.',
    'urdu': 'Respond in Urdu script.',
    'roman-english': 'Respond in Roman Urdu/Hinglish.'
  };

  const response = await ai.models.generateContent({
    model: 'gemini-3-flash-preview',
    contents: `Fact check this statement: "${statement}". 
    Provide a truth score from 0 to 100 (where 100 is absolute truth and 0 is complete lie/falsehood). 
    Provide a short verdict and a detailed explanation. 
    ${langInstructions[language]}`,
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          score: { type: Type.INTEGER, description: "Truth percentage 0-100" },
          verdict: { type: Type.STRING, description: "Short verdict e.g. True, False, Misleading" },
          explanation: { type: Type.STRING, description: "Detailed reasoning" }
        },
        required: ["score", "verdict", "explanation"]
      }
    }
  });

  try {
    return JSON.parse(response.text || "{}");
  } catch (e) {
    return { score: 50, verdict: "Inconclusive", explanation: "Could not verify information." };
  }
};

export const summarizeNotes = async (text: string, imageData?: string): Promise<string> => {
  const ai = getAIClient();
  const parts: any[] = [{ text: `Summarize these study notes into a structured format with key takeaways. Use Markdown. Input: ${text}` }];
  
  if (imageData) {
    parts.push({
      inlineData: {
        mimeType: 'image/jpeg',
        data: imageData
      }
    });
  }

  const response = await ai.models.generateContent({
    model: 'gemini-3-flash-preview',
    contents: { parts },
    config: {
        systemInstruction: "You are an expert academic tutor. Provide clear, concise, and helpful summaries."
    }
  });

  return response.text || "Failed to generate summary.";
};

export const generateQuiz = async (input: string, mode: 'notes' | 'topic' = 'notes'): Promise<any[]> => {
  const ai = getAIClient();
  const prompt = mode === 'notes' 
    ? `Generate 5 high-quality multiple choice questions in JSON format based on the following text content: ${input}`
    : `Generate 5 high-quality multiple choice questions in JSON format about the specific subject or topic: ${input}`;

  const response = await ai.models.generateContent({
    model: 'gemini-3-flash-preview',
    contents: prompt,
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.ARRAY,
        items: {
          type: Type.OBJECT,
          properties: {
            question: { type: Type.STRING },
            options: { type: Type.ARRAY, items: { type: Type.STRING } },
            correctAnswer: { type: Type.INTEGER, description: "Zero-based index" },
            explanation: { type: Type.STRING }
          },
          required: ["question", "options", "correctAnswer", "explanation"]
        }
      }
    }
  });

  try {
    return JSON.parse(response.text || "[]");
  } catch (e) {
    console.error("Failed to parse quiz JSON", e);
    return [];
  }
};

// LIVE API UTILS
export function decode(base64: string) {
  const binaryString = atob(base64);
  const len = binaryString.length;
  const bytes = new Uint8Array(len);
  for (let i = 0; i < len; i++) {
    bytes[i] = binaryString.charCodeAt(i);
  }
  return bytes;
}

export function encode(bytes: Uint8Array) {
  let binary = '';
  const len = bytes.byteLength;
  for (let i = 0; i < len; i++) {
    binary += String.fromCharCode(bytes[i]);
  }
  return btoa(binary);
}

export async function decodeAudioData(
  data: Uint8Array,
  ctx: AudioContext,
  sampleRate: number,
  numChannels: number,
): Promise<AudioBuffer> {
  // Use data.buffer with byteOffset and byteLength to handle potential slice offsets
  const dataInt16 = new Int16Array(data.buffer, data.byteOffset, data.byteLength / 2);
  const frameCount = dataInt16.length / numChannels;
  const buffer = ctx.createBuffer(numChannels, frameCount, sampleRate);

  for (let channel = 0; channel < numChannels; channel++) {
    const channelData = buffer.getChannelData(channel);
    for (let i = 0; i < frameCount; i++) {
      channelData[i] = dataInt16[i * numChannels + channel] / 32768.0;
    }
  }
  return buffer;
}
